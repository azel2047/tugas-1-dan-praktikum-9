<?php
define('APP_START', true);
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../auth/check_auth.php';

requireLogin();

$errors = [];
$old    = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCsrf();
    $nama    = trim($_POST['nama'] ?? '');
    $old['nama'] = htmlspecialchars($nama);

    if (empty($nama))          $errors['nama'] = 'Nama level wajib diisi.';
    elseif (strlen($nama) > 100) $errors['nama'] = 'Nama level maksimal 100 karakter.';

    if (empty($errors)) {
        $exists = dbFetchOne('SELECT id FROM level WHERE nama = ? LIMIT 1', 's', [$nama]);
        if ($exists) $errors['nama'] = 'Level dengan nama tersebut sudah ada.';
    }

    if (empty($errors)) {
        dbExecute('INSERT INTO level (nama) VALUES (?)', 's', [$nama]);
        setFlash('success', 'Level "' . $nama . '" berhasil ditambahkan.');
        header('Location: ' . BASE_URL . '/crud/level/index.php');
        exit;
    }
}

$pageTitle  = 'Tambah Level';
$breadcrumb = [
    ['label' => 'Level Pendidikan', 'url' => BASE_URL . '/crud/level/index.php'],
    ['label' => 'Tambah',           'url' => ''],
];
require_once __DIR__ . '/../../partials/dashboard_layout.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="dash-card">
            <div class="dash-card-header">
                <h6 class="dash-card-title"><i class="bi bi-plus-circle me-2 text-primary"></i>Tambah Level Baru</h6>
                <a href="<?= BASE_URL ?>/crud/level/index.php" class="dash-btn dash-btn-outline">
                    <i class="bi bi-arrow-left me-1"></i>Kembali
                </a>
            </div>
            <div class="dash-card-body">
                <form method="POST" action="" novalidate>
                    <?= csrfField() ?>

                    <div class="mb-4">
                        <label for="nama" class="form-label fw-semibold" style="font-size:.85rem;">
                            Nama Level <span class="text-danger">*</span>
                        </label>
                        <input type="text" id="nama" name="nama"
                               class="form-control dash-input <?= !empty($errors['nama']) ? 'is-invalid' : '' ?>"
                               value="<?= $old['nama'] ?? '' ?>"
                               placeholder="Contoh: TK, SD, SMP, SMA, D3, S1 ..."
                               maxlength="100" required autofocus>
                        <?php if (!empty($errors['nama'])): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($errors['nama']) ?></div>
                        <?php endif; ?>
                        <div class="form-text" style="font-size:.75rem;">Nama tingkat pendidikan, maksimal 100 karakter.</div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="dash-btn dash-btn-primary px-4">
                            <i class="bi bi-save me-1"></i> Simpan Level
                        </button>
                        <a href="<?= BASE_URL ?>/crud/level/index.php" class="dash-btn dash-btn-outline">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../partials/dashboard_layout_close.php'; ?>
