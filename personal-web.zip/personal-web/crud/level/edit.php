<?php
define('APP_START', true);
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../auth/check_auth.php';

requireLogin();

$id = (int) ($_GET['id'] ?? 0);
if ($id <= 0) { setFlash('error','ID tidak valid.'); header('Location: '.BASE_URL.'/crud/level/index.php'); exit; }

$level = dbFetchOne('SELECT * FROM level WHERE id = ? LIMIT 1','i',[$id]);
if (!$level) { setFlash('error','Level tidak ditemukan.'); header('Location: '.BASE_URL.'/crud/level/index.php'); exit; }

$errors = [];
$old    = ['nama' => htmlspecialchars($level['nama'])];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCsrf();
    $nama = trim($_POST['nama'] ?? '');
    $old['nama'] = htmlspecialchars($nama);

    if (empty($nama))          $errors['nama'] = 'Nama level wajib diisi.';
    elseif (strlen($nama)>100) $errors['nama'] = 'Nama level maksimal 100 karakter.';

    if (empty($errors)) {
        $dup = dbFetchOne('SELECT id FROM level WHERE nama=? AND id!=? LIMIT 1','si',[$nama,$id]);
        if ($dup) $errors['nama'] = 'Level dengan nama tersebut sudah ada.';
    }

    if (empty($errors)) {
        dbExecute('UPDATE level SET nama=? WHERE id=?','si',[$nama,$id]);
        setFlash('success','Level berhasil diperbarui.');
        header('Location: '.BASE_URL.'/crud/level/index.php');
        exit;
    }
}

$pageTitle  = 'Edit Level';
$breadcrumb = [
    ['label' => 'Level Pendidikan', 'url' => BASE_URL . '/crud/level/index.php'],
    ['label' => 'Edit: ' . $level['nama'], 'url' => ''],
];
require_once __DIR__ . '/../../partials/dashboard_layout.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="dash-card">
            <div class="dash-card-header">
                <h6 class="dash-card-title">
                    <i class="bi bi-pencil-square me-2 text-primary"></i>Edit Level
                    <span class="dash-badge ms-2" style="background:#f1f5f9;color:#64748b;">ID: <?= $level['id'] ?></span>
                </h6>
                <a href="<?= BASE_URL ?>/crud/level/index.php" class="dash-btn dash-btn-outline">
                    <i class="bi bi-arrow-left me-1"></i>Kembali
                </a>
            </div>
            <div class="dash-card-body">
                <form method="POST" action="" novalidate>
                    <?= csrfField() ?>

                    <div class="mb-4">
                        <label for="nama" class="form-label fw-semibold" style="font-size:.85rem;">
                            Nama Level <span class="text-danger">*</span>
                        </label>
                        <input type="text" id="nama" name="nama"
                               class="form-control dash-input <?= !empty($errors['nama']) ? 'is-invalid' : '' ?>"
                               value="<?= $old['nama'] ?>"
                               maxlength="100" required autofocus>
                        <?php if (!empty($errors['nama'])): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($errors['nama']) ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="dash-btn dash-btn-primary px-4">
                            <i class="bi bi-save me-1"></i> Perbarui
                        </button>
                        <a href="<?= BASE_URL ?>/crud/level/index.php" class="dash-btn dash-btn-outline">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../partials/dashboard_layout_close.php'; ?>
