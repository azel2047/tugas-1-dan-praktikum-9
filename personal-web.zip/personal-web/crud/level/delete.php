<?php
define('APP_START', true);
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../auth/check_auth.php';

requireLogin();
startSecureSession();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . BASE_URL . '/crud/level/index.php');
    exit;
}

validateCsrf();

$id = (int) ($_POST['id'] ?? 0);
if ($id <= 0) {
    setFlash('error', 'ID level tidak valid.');
    header('Location: ' . BASE_URL . '/crud/level/index.php');
    exit;
}

// Check if level exists
$level = dbFetchOne('SELECT * FROM level WHERE id = ? LIMIT 1', 'i', [$id]);
if (!$level) {
    setFlash('error', 'Level tidak ditemukan.');
    header('Location: ' . BASE_URL . '/crud/level/index.php');
    exit;
}

// Check if level is used by studies (FK constraint)
$usage = dbFetchOne('SELECT COUNT(*) as cnt FROM studies WHERE idlevel = ?', 'i', [$id]);
if ($usage && $usage['cnt'] > 0) {
    setFlash('error', 'Level "' . $level['nama'] . '" tidak dapat dihapus karena masih digunakan oleh ' . $usage['cnt'] . ' data studi.');
    header('Location: ' . BASE_URL . '/crud/level/index.php');
    exit;
}

try {
    dbExecute('DELETE FROM level WHERE id = ?', 'i', [$id]);
    setFlash('success', 'Level "' . $level['nama'] . '" berhasil dihapus.');
} catch (Exception $e) {
    setFlash('error', 'Gagal menghapus level. ' . ($e->getMessage() ?? ''));
}

header('Location: ' . BASE_URL . '/crud/level/index.php');
exit;
