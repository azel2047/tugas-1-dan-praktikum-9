<?php
define('APP_START', true);
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../auth/check_auth.php';

requireLogin();

$levels     = dbFetchAll('SELECT * FROM level ORDER BY id ASC');
$pageTitle  = 'Level Pendidikan';
$breadcrumb = [['label' => 'Level Pendidikan', 'url' => '']];

require_once __DIR__ . '/../../partials/dashboard_layout.php';
?>

<div class="dash-card">
    <!-- Card Header -->
    <div class="dash-card-header">
        <h6 class="dash-card-title">
            <i class="bi bi-layers me-2 text-primary"></i>
            Daftar Level Pendidikan
            <span class="dash-badge ms-2" style="background:rgba(59,130,246,.1);color:#3b82f6;">
                <?= count($levels) ?> level
            </span>
        </h6>
        <a href="<?= BASE_URL ?>/crud/level/create.php" class="dash-btn dash-btn-primary">
            <i class="bi bi-plus-lg"></i> Tambah Level
        </a>
    </div>

    <!-- Table -->
    <?php if (empty($levels)): ?>
        <div class="dash-card-body text-center py-5 text-muted">
            <i class="bi bi-inbox" style="font-size:2.5rem;"></i>
            <p class="mt-3 mb-3">Belum ada data level. Tambahkan sekarang.</p>
            <a href="<?= BASE_URL ?>/crud/level/create.php" class="dash-btn dash-btn-primary">
                <i class="bi bi-plus-lg"></i> Tambah Level Pertama
            </a>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table dash-table mb-0">
                <thead>
                    <tr>
                        <th style="width:60px;">#</th>
                        <th>Nama Level</th>
                        <th>Jumlah Studi</th>
                        <th class="text-center" style="width:140px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($levels as $i => $lv):
                        $cnt = dbFetchOne('SELECT COUNT(*) AS c FROM studies WHERE idlevel = ?', 'i', [$lv['id']])['c'] ?? 0;
                    ?>
                    <tr>
                        <td style="color:#94a3b8;"><?= $i + 1 ?></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div style="width:32px;height:32px;border-radius:8px;
                                            background:rgba(59,130,246,.1);
                                            display:flex;align-items:center;justify-content:center;
                                            color:#3b82f6;">
                                    <i class="bi bi-layers"></i>
                                </div>
                                <span class="fw-semibold"><?= htmlspecialchars($lv['nama']) ?></span>
                            </div>
                        </td>
                        <td>
                            <?php if ($cnt > 0): ?>
                                <span class="dash-badge" style="background:rgba(16,185,129,.1);color:#10b981;">
                                    <i class="bi bi-mortarboard me-1"></i><?= $cnt ?> studi
                                </span>
                            <?php else: ?>
                                <span class="dash-badge" style="background:#f1f5f9;color:#94a3b8;">Belum ada</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <div class="d-flex gap-1 justify-content-center">
                                <a href="<?= BASE_URL ?>/crud/level/edit.php?id=<?= $lv['id'] ?>"
                                   class="dash-btn dash-btn-outline" style="padding:.3rem .6rem;">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <button class="dash-btn dash-btn-danger" style="padding:.3rem .6rem;"
                                        data-bs-toggle="modal" data-bs-target="#deleteModal"
                                        data-id="<?= $lv['id'] ?>" data-name="<?= htmlspecialchars($lv['nama']) ?>">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered" style="max-width:400px;">
        <div class="modal-content" style="border-radius:16px;border:none;box-shadow:0 20px 60px rgba(0,0,0,.15);">
            <div class="modal-body p-4 text-center">
                <div style="width:56px;height:56px;background:#fef2f2;border-radius:50%;
                            display:flex;align-items:center;justify-content:center;
                            margin:0 auto 16px;font-size:1.5rem;color:#ef4444;">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                </div>
                <h5 class="fw-bold mb-2">Hapus Level?</h5>
                <p class="text-muted small mb-4">
                    Anda yakin ingin menghapus level <strong id="deleteItemName"></strong>?<br>
                    Level yang masih digunakan studi tidak bisa dihapus.
                </p>
                <div class="d-flex gap-2 justify-content-center">
                    <button class="dash-btn dash-btn-outline px-4" data-bs-dismiss="modal">Batal</button>
                    <form method="POST" action="<?= BASE_URL ?>/crud/level/delete.php">
                        <?= csrfField() ?>
                        <input type="hidden" name="id" id="deleteId">
                        <button type="submit" class="dash-btn dash-btn-danger px-4">
                            <i class="bi bi-trash me-1"></i> Hapus
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../partials/dashboard_layout_close.php'; ?>
