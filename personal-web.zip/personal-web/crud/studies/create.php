<?php
define('APP_START', true);
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../auth/check_auth.php';

requireLogin();

$levels = dbFetchAll('SELECT * FROM level ORDER BY nama ASC');
$errors = [];
$old    = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCsrf();
    $nama        = trim($_POST['nama']       ?? '');
    $idlevel     = (int)($_POST['idlevel']   ?? 0);
    $keterangan  = trim($_POST['keterangan'] ?? '');
    $tahun_lulus = (int)($_POST['tahun_lulus'] ?? 0);

    $old = [
        'nama'        => htmlspecialchars($nama),
        'idlevel'     => $idlevel,
        'keterangan'  => htmlspecialchars($keterangan),
        'tahun_lulus' => $tahun_lulus,
    ];

    if (empty($nama))    $errors['nama']        = 'Nama institusi wajib diisi.';
    if ($idlevel <= 0)   $errors['idlevel']     = 'Pilih level pendidikan.';
    if ($tahun_lulus < 1900 || $tahun_lulus > (int)date('Y') + 5)
        $errors['tahun_lulus'] = 'Tahun lulus tidak valid (1900–' . ((int)date('Y') + 5) . ').';

    if ($idlevel > 0 && empty($errors['idlevel'])) {
        if (!dbFetchOne('SELECT id FROM level WHERE id=? LIMIT 1','i',[$idlevel]))
            $errors['idlevel'] = 'Level tidak valid.';
    }

    $fotoNama = null;
    if (!empty($_FILES['foto_sekolah']['name'])) {
        $file    = $_FILES['foto_sekolah'];
        $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $fotoNama = uniqid('study_', true) . '.' . $ext;
        if ($file['error'] !== UPLOAD_ERR_OK)           { $errors['foto'] = 'Error upload.'; $fotoNama=null; }
        elseif (!in_array($ext, ALLOWED_EXTENSIONS))     { $errors['foto'] = 'Format tidak didukung (JPG/PNG/GIF/WEBP).'; $fotoNama=null; }
        elseif ($file['size'] > MAX_FILE_SIZE)           { $errors['foto'] = 'File terlalu besar (maks. 2 MB).'; $fotoNama=null; }
        else {
            if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR,0755,true);
            if (!move_uploaded_file($file['tmp_name'], UPLOAD_DIR . $fotoNama)) { $errors['foto']='Gagal simpan file.'; $fotoNama=null; }
        }
    }

    if (empty($errors)) {
        dbExecute(
            'INSERT INTO studies (nama,idlevel,keterangan,tahun_lulus,foto_sekolah) VALUES (?,?,?,?,?)',
            'sissi',
            [$nama, $idlevel, $keterangan, $tahun_lulus, $fotoNama]
        );
        setFlash('success', 'Data studi "' . $nama . '" berhasil ditambahkan.');
        header('Location: ' . BASE_URL . '/crud/studies/index.php');
        exit;
    }
}

$pageTitle  = 'Tambah Studi';
$breadcrumb = [
    ['label' => 'Data Studies', 'url' => BASE_URL . '/crud/studies/index.php'],
    ['label' => 'Tambah',       'url' => ''],
];
require_once __DIR__ . '/../../partials/dashboard_layout.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="dash-card">
            <div class="dash-card-header">
                <h6 class="dash-card-title"><i class="bi bi-plus-circle me-2 text-primary"></i>Tambah Data Studi Baru</h6>
                <a href="<?= BASE_URL ?>/crud/studies/index.php" class="dash-btn dash-btn-outline">
                    <i class="bi bi-arrow-left me-1"></i>Kembali
                </a>
            </div>
            <div class="dash-card-body">
                <form method="POST" action="" enctype="multipart/form-data" novalidate>
                    <?= csrfField() ?>

                    <div class="row g-3">
                        <!-- Nama -->
                        <div class="col-12">
                            <label for="nama" class="form-label fw-semibold" style="font-size:.85rem;">
                                Nama Institusi <span class="text-danger">*</span>
                            </label>
                            <input type="text" id="nama" name="nama"
                                   class="form-control dash-input <?= !empty($errors['nama']) ? 'is-invalid':'' ?>"
                                   value="<?= $old['nama'] ?? '' ?>"
                                   placeholder="Contoh: SDN 01 Cerdas Bangsa ..."
                                   maxlength="150" required autofocus>
                            <?php if (!empty($errors['nama'])): ?>
                                <div class="invalid-feedback"><?= htmlspecialchars($errors['nama']) ?></div>
                            <?php endif; ?>
                        </div>

                        <!-- Level -->
                        <div class="col-md-6">
                            <label for="idlevel" class="form-label fw-semibold" style="font-size:.85rem;">
                                Level Pendidikan <span class="text-danger">*</span>
                            </label>
                            <select id="idlevel" name="idlevel"
                                    class="form-select dash-input <?= !empty($errors['idlevel']) ? 'is-invalid':'' ?>" required>
                                <option value="">-- Pilih Level --</option>
                                <?php foreach ($levels as $lv): ?>
                                    <option value="<?= $lv['id'] ?>"
                                        <?= (isset($old['idlevel']) && $old['idlevel']==$lv['id']) ? 'selected':'' ?>>
                                        <?= htmlspecialchars($lv['nama']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (!empty($errors['idlevel'])): ?>
                                <div class="invalid-feedback"><?= htmlspecialchars($errors['idlevel']) ?></div>
                            <?php endif; ?>
                        </div>

                        <!-- Tahun Lulus -->
                        <div class="col-md-6">
                            <label for="tahun_lulus" class="form-label fw-semibold" style="font-size:.85rem;">
                                Tahun Lulus <span class="text-danger">*</span>
                            </label>
                            <input type="number" id="tahun_lulus" name="tahun_lulus"
                                   class="form-control dash-input <?= !empty($errors['tahun_lulus']) ? 'is-invalid':'' ?>"
                                   value="<?= $old['tahun_lulus'] ?? date('Y') ?>"
                                   min="1900" max="<?= date('Y')+5 ?>" required>
                            <?php if (!empty($errors['tahun_lulus'])): ?>
                                <div class="invalid-feedback"><?= htmlspecialchars($errors['tahun_lulus']) ?></div>
                            <?php endif; ?>
                        </div>

                        <!-- Keterangan -->
                        <div class="col-12">
                            <label for="keterangan" class="form-label fw-semibold" style="font-size:.85rem;">Keterangan</label>
                            <textarea id="keterangan" name="keterangan" rows="3"
                                      class="form-control dash-input"
                                      placeholder="Deskripsi singkat tentang institusi atau pengalaman belajar..."><?= $old['keterangan'] ?? '' ?></textarea>
                        </div>

                        <!-- Foto -->
                        <div class="col-12">
                            <label class="form-label fw-semibold" style="font-size:.85rem;">Foto Sekolah</label>
                            <input type="file" id="foto_sekolah" name="foto_sekolah" accept="image/*"
                                   class="form-control dash-input <?= !empty($errors['foto']) ? 'is-invalid':'' ?>">
                            <?php if (!empty($errors['foto'])): ?>
                                <div class="invalid-feedback"><?= htmlspecialchars($errors['foto']) ?></div>
                            <?php endif; ?>
                            <div class="form-text" style="font-size:.75rem;">JPG, PNG, GIF, WEBP — Maks. 2 MB</div>
                            <!-- Preview -->
                            <div id="previewContainer" style="display:none;margin-top:10px;">
                                <img id="previewImg" src="#" alt="Preview"
                                     style="max-height:140px;border-radius:10px;border:2px solid #e2e8f0;">
                            </div>
                        </div>
                    </div>

                    <hr style="border-color:#f1f5f9;margin:24px 0;">

                    <div class="d-flex gap-2">
                        <button type="submit" class="dash-btn dash-btn-primary px-4">
                            <i class="bi bi-save me-1"></i> Simpan Data
                        </button>
                        <a href="<?= BASE_URL ?>/crud/studies/index.php" class="dash-btn dash-btn-outline">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../partials/dashboard_layout_close.php'; ?>
