<?php
define('APP_START', true);
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../auth/check_auth.php';

requireLogin();
startSecureSession();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . BASE_URL . '/crud/studies/index.php');
    exit;
}

validateCsrf();

$id = (int) ($_POST['id'] ?? 0);
if ($id <= 0) {
    setFlash('error', 'ID studi tidak valid.');
    header('Location: ' . BASE_URL . '/crud/studies/index.php');
    exit;
}

$study = dbFetchOne('SELECT * FROM studies WHERE id = ? LIMIT 1', 'i', [$id]);
if (!$study) {
    setFlash('error', 'Data studi tidak ditemukan.');
    header('Location: ' . BASE_URL . '/crud/studies/index.php');
    exit;
}

try {
    dbExecute('DELETE FROM studies WHERE id = ?', 'i', [$id]);

    // Delete associated photo file
    if ($study['foto_sekolah']) {
        $filePath = UPLOAD_DIR . $study['foto_sekolah'];
        if (file_exists($filePath)) {
            @unlink($filePath);
        }
    }

    setFlash('success', 'Data studi "' . $study['nama'] . '" berhasil dihapus.');
} catch (Exception $e) {
    setFlash('error', 'Gagal menghapus data studi.');
}

header('Location: ' . BASE_URL . '/crud/studies/index.php');
exit;
