<?php
define('APP_START', true);
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../auth/check_auth.php';

requireLogin();

$studies = dbFetchAll(
    'SELECT s.*, l.nama AS nama_level FROM studies s
     JOIN level l ON s.idlevel=l.id
     ORDER BY s.tahun_lulus ASC, s.id ASC'
);

$pageTitle  = 'Data Studies';
$breadcrumb = [['label' => 'Data Studies', 'url' => '']];
require_once __DIR__ . '/../../partials/dashboard_layout.php';
?>

<div class="dash-card">
    <div class="dash-card-header">
        <h6 class="dash-card-title">
            <i class="bi bi-mortarboard me-2 text-primary"></i>
            Daftar Riwayat Studi
            <span class="dash-badge ms-2" style="background:rgba(59,130,246,.1);color:#3b82f6;">
                <?= count($studies) ?> data
            </span>
        </h6>
        <a href="<?= BASE_URL ?>/crud/studies/create.php" class="dash-btn dash-btn-primary">
            <i class="bi bi-plus-lg"></i> Tambah Studi
        </a>
    </div>

    <?php if (empty($studies)): ?>
        <div class="dash-card-body text-center py-5 text-muted">
            <i class="bi bi-inbox" style="font-size:2.5rem;"></i>
            <p class="mt-3 mb-3">Belum ada data studi.</p>
            <a href="<?= BASE_URL ?>/crud/studies/create.php" class="dash-btn dash-btn-primary">
                <i class="bi bi-plus-lg"></i> Tambah Sekarang
            </a>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table dash-table mb-0">
                <thead>
                    <tr>
                        <th style="width:50px;">#</th>
                        <th>Institusi</th>
                        <th>Level</th>
                        <th>Tahun Lulus</th>
                        <th>Foto</th>
                        <th class="text-center" style="width:120px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($studies as $i => $s): ?>
                    <tr>
                        <td style="color:#94a3b8;"><?= $i + 1 ?></td>
                        <td>
                            <div class="fw-semibold" style="font-size:.875rem;"><?= htmlspecialchars($s['nama']) ?></div>
                            <?php if ($s['keterangan']): ?>
                            <div style="font-size:.75rem;color:#94a3b8;max-width:240px;
                                        white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                                <?= htmlspecialchars($s['keterangan']) ?>
                            </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="dash-badge" style="background:rgba(59,130,246,.1);color:#3b82f6;">
                                <?= htmlspecialchars($s['nama_level']) ?>
                            </span>
                        </td>
                        <td style="font-weight:600;color:#1e293b;"><?= $s['tahun_lulus'] ?></td>
                        <td>
                            <?php if ($s['foto_sekolah'] && file_exists(UPLOAD_DIR . $s['foto_sekolah'])): ?>
                                <img src="<?= UPLOAD_URL . htmlspecialchars($s['foto_sekolah']) ?>"
                                     alt="foto" style="width:40px;height:40px;object-fit:cover;border-radius:8px;
                                                       border:2px solid #e2e8f0;">
                            <?php else: ?>
                                <div style="width:40px;height:40px;background:#f1f5f9;border-radius:8px;
                                            display:flex;align-items:center;justify-content:center;color:#cbd5e1;">
                                    <i class="bi bi-image"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <div class="d-flex gap-1 justify-content-center">
                                <a href="<?= BASE_URL ?>/crud/studies/edit.php?id=<?= $s['id'] ?>"
                                   class="dash-btn dash-btn-outline" style="padding:.3rem .6rem;">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <button class="dash-btn dash-btn-danger" style="padding:.3rem .6rem;"
                                        data-bs-toggle="modal" data-bs-target="#deleteModal"
                                        data-id="<?= $s['id'] ?>" data-name="<?= htmlspecialchars($s['nama']) ?>">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered" style="max-width:400px;">
        <div class="modal-content" style="border-radius:16px;border:none;box-shadow:0 20px 60px rgba(0,0,0,.15);">
            <div class="modal-body p-4 text-center">
                <div style="width:56px;height:56px;background:#fef2f2;border-radius:50%;
                            display:flex;align-items:center;justify-content:center;
                            margin:0 auto 16px;font-size:1.5rem;color:#ef4444;">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                </div>
                <h5 class="fw-bold mb-2">Hapus Data Studi?</h5>
                <p class="text-muted small mb-4">
                    Anda yakin ingin menghapus <strong id="deleteItemName"></strong>?<br>
                    <span class="text-danger">Foto terkait juga akan dihapus permanen.</span>
                </p>
                <div class="d-flex gap-2 justify-content-center">
                    <button class="dash-btn dash-btn-outline px-4" data-bs-dismiss="modal">Batal</button>
                    <form method="POST" action="<?= BASE_URL ?>/crud/studies/delete.php">
                        <?= csrfField() ?>
                        <input type="hidden" name="id" id="deleteId">
                        <button type="submit" class="dash-btn dash-btn-danger px-4">
                            <i class="bi bi-trash me-1"></i>Hapus
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../partials/dashboard_layout_close.php'; ?>
