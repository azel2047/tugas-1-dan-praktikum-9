<?php
session_start();
$user = $_SESSION['user'] ?? null;
$studies = dbFetchAll(
    'SELECT s.*, l.nama AS nama_level
     FROM studies s
     JOIN level l ON s.idlevel = l.id
     ORDER BY s.tahun_lulus ASC, s.id ASC'
);
?>
<div class="page-studies">
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-4">
        <div>
            <h1 class="h3 fw-bold mb-1">Riwayat Pendidikan</h1>
            <p class="text-muted mb-0">Perjalanan akademis saya dari TK hingga perguruan tinggi.</p>
        </div>
        <?php if ($user): ?>
        <div class="d-flex gap-2">
            <a href="<?= BASE_URL ?>/crud/studies/create.php" class="btn btn-primary btn-sm rounded-pill px-3">
                <i class="bi bi-plus-lg me-1"></i>Tambah
            </a>
            <a href="<?= BASE_URL ?>/crud/studies/index.php" class="btn btn-outline-primary btn-sm rounded-pill px-3">
                <i class="bi bi-pencil me-1"></i>Kelola
            </a>
        </div>
        <?php else: ?>
        <div class="text-end">
            <small class="text-muted d-block">Untuk mengelola data,</small>
            <a href="<?= BASE_URL ?>/auth/login.php" class="btn btn-sm btn-outline-primary rounded-pill px-3">
                <i class="bi bi-box-arrow-in-right me-1"></i>Login dulu
            </a>
        </div>
        <?php endif; ?>
    </div>

    <?php if (empty($studies)): ?>
        <div class="glass-card p-5 text-center text-muted">
            <i class="bi bi-mortarboard" style="font-size:3rem;"></i>
            <p class="mt-3 mb-0">Belum ada data pendidikan.</p>
            <?php if ($user): ?>
            <a href="<?= BASE_URL ?>/crud/studies/create.php" class="btn btn-primary mt-3">
                <i class="bi bi-plus me-1"></i>Tambah Studi Pertama
            </a>
            <?php endif; ?>
        </div>
    <?php else: ?>

        <!-- Timeline layout -->
        <div class="studies-timeline">
            <?php foreach ($studies as $i => $study): ?>
            <div class="study-item glass-card p-4 mb-3 d-flex gap-4 align-items-start">

                <!-- Year Badge -->
                <div class="study-year text-center flex-shrink-0">
                    <div class="year-circle">
                        <?= htmlspecialchars($study['tahun_lulus']) ?>
                    </div>
                    <div class="text-muted" style="font-size:.65rem; margin-top:4px;">Lulus</div>
                </div>

                <!-- Content -->
                <div class="flex-grow-1">
                    <div class="d-flex align-items-start justify-content-between flex-wrap gap-2 mb-2">
                        <div>
                            <h5 class="fw-bold mb-0"><?= htmlspecialchars($study['nama']) ?></h5>
                            <span class="badge bg-primary-subtle text-primary border border-primary-subtle rounded-pill px-2 mt-1">
                                <i class="bi bi-layers me-1"></i><?= htmlspecialchars($study['nama_level']) ?>
                            </span>
                        </div>

                        <!-- Photo (if available) -->
                        <?php if ($study['foto_sekolah'] && file_exists(UPLOAD_DIR . $study['foto_sekolah'])): ?>
                        <img src="<?= UPLOAD_URL . htmlspecialchars($study['foto_sekolah']) ?>"
                             alt="<?= htmlspecialchars($study['nama']) ?>"
                             class="rounded-3 flex-shrink-0"
                             style="width:70px;height:70px;object-fit:cover;">
                        <?php else: ?>
                        <div class="school-placeholder flex-shrink-0 rounded-3 d-flex align-items-center justify-content-center"
                             style="width:70px;height:70px;background:rgba(var(--bs-primary-rgb),.08);">
                            <i class="bi bi-building text-primary" style="font-size:1.8rem;"></i>
                        </div>
                        <?php endif; ?>
                    </div>

                    <?php if ($study['keterangan']): ?>
                    <p class="text-muted small mb-2"><?= nl2br(htmlspecialchars($study['keterangan'])) ?></p>
                    <?php endif; ?>

                    <?php if ($user): ?>
                    <div class="d-flex gap-2 mt-2">
                        <a href="<?= BASE_URL ?>/crud/studies/edit.php?id=<?= $study['id'] ?>"
                           class="btn btn-xs btn-outline-primary" style="font-size:.75rem; padding:.2rem .6rem;">
                            <i class="bi bi-pencil me-1"></i>Edit
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

    <?php endif; ?>
</div>
