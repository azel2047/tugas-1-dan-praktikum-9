<?php
?>
<div class="page-contact">

    <!-- Page Header -->
    <div class="mb-4">
        <h1 class="h3 fw-bold mb-1">Hubungi Saya</h1>
        <p class="text-muted mb-0">
            Temukan dan terhubung dengan saya di berbagai platform media sosial.
        </p>
    </div>

    <!-- Primary Contact Banner -->
    <div class="glass-card p-4 mb-4 contact-banner">
        <div class="row align-items-center g-3">
            <div class="col-md-8">
                <h5 class="fw-bold mb-2">Ingin bekerja sama?</h5>
                <p class="text-muted mb-0">
                    Saya terbuka untuk peluang freelance, kolaborasi project, atau sekadar berdiskusi tentang teknologi.
                    Jangan ragu untuk menghubungi <strong>Ugroseno Dwi Prakastyo</strong>!
                </p>
            </div>
            <div class="col-md-4 text-md-end">
                <a href="mailto:azelxiteer@gmail.com" class="btn btn-primary rounded-pill px-4">
                    <i class="bi bi-envelope-fill me-2"></i>Kirim Email
                </a>
            </div>
        </div>
    </div>

    <!-- Social Media Card Groups -->
    <h5 class="fw-bold mb-3">Platform Sosial Media</h5>
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3 mb-4">
        <?php
        $socials = [
            [
                'platform' => 'GitHub',
                'icon'     => 'bi-github',
                'color'    => '#24292e',
                'bg'       => 'rgba(36,41,46,.08)',
                'username' => '@ugroseno',
                'link'     => 'https://github.com/ugroseno',
                'desc'     => 'Lihat proyek open-source dan repositori kode saya',
                'badge'    => 'Code Repository',
            ],
            [
                'platform' => 'LinkedIn',
                'icon'     => 'bi-linkedin',
                'color'    => '#0077b5',
                'bg'       => 'rgba(0,119,181,.08)',
                'username' => 'Ugroseno Dwi Prakastyo',
                'link'     => 'https://linkedin.com/in/ugroseno',
                'desc'     => 'Jaringan profesional dan riwayat karier lengkap saya',
                'badge'    => 'Professional',
            ],
            [
                'platform' => 'Instagram',
                'icon'     => 'bi-instagram',
                'color'    => '#e1306c',
                'bg'       => 'rgba(225,48,108,.08)',
                'username' => '@ugroseno',
                'link'     => 'https://instagram.com/ugroseno',
                'desc'     => 'Momen kehidupan sehari-hari dan konten visual menarik',
                'badge'    => 'Lifestyle',
            ],
            [
                'platform' => 'Twitter / X',
                'icon'     => 'bi-twitter-x',
                'color'    => '#000000',
                'bg'       => 'rgba(0,0,0,.08)',
                'username' => '@ugroseno',
                'link'     => 'https://twitter.com/ugroseno',
                'desc'     => 'Berbagi pemikiran dan update terbaru tentang teknologi',
                'badge'    => 'Microblog',
            ],
            [
                'platform' => 'WhatsApp',
                'icon'     => 'bi-whatsapp',
                'color'    => '#25d366',
                'bg'       => 'rgba(37,211,102,.08)',
                'username' => '+62 8xx xxxx xxxx',
                'link'     => 'https://wa.me/62',
                'desc'     => 'Chat langsung untuk diskusi cepat dan kolaborasi',
                'badge'    => 'Messaging',
            ],
            [
                'platform' => 'Email',
                'icon'     => 'bi-envelope-fill',
                'color'    => '#ea4335',
                'bg'       => 'rgba(234,67,53,.08)',
                'username' => 'azelxiteer@gmail.com',
                'link'     => 'mailto:azelxiteer@gmail.com',
                'desc'     => 'Untuk keperluan resmi, kerjasama, dan proposal proyek',
                'badge'    => 'Official',
            ],
        ];

        foreach ($socials as $s): ?>
        <div class="col">
            <div class="card social-card glass-card border-0 h-100">

                <!-- Icon Area -->
                <div class="social-icon-area d-flex align-items-center justify-content-center"
                     style="background:<?= $s['bg'] ?>; height:100px; border-radius:16px 16px 0 0;">
                    <div class="social-main-icon" style="color:<?= $s['color'] ?>;">
                        <i class="bi <?= $s['icon'] ?>"></i>
                    </div>
                </div>

                <div class="card-body p-3">
                    <!-- Category Badge -->
                    <div class="mb-2">
                        <span class="badge rounded-pill px-2 py-1"
                              style="background:<?= $s['bg'] ?>; color:<?= $s['color'] ?>; font-size:.68rem;
                                     border:1px solid <?= $s['color'] ?>30;">
                            <?= $s['badge'] ?>
                        </span>
                    </div>

                    <h6 class="card-title fw-bold mb-1"><?= $s['platform'] ?></h6>

                    <!-- Username -->
                    <p class="fw-semibold small mb-1" style="color:<?= $s['color'] ?>;">
                        <?= htmlspecialchars($s['username']) ?>
                    </p>

                    <!-- Description -->
                    <p class="card-text text-muted small mb-3">
                        <?= $s['desc'] ?>
                    </p>

                    <!-- Visit Button -->
                    <a href="<?= $s['link'] ?>" target="_blank" rel="noopener noreferrer"
                       class="btn btn-sm w-100 rounded-pill"
                       style="background:<?= $s['color'] ?>15; color:<?= $s['color'] ?>;
                              border:1px solid <?= $s['color'] ?>40;">
                        <i class="bi <?= $s['icon'] ?> me-1"></i> Kunjungi
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Direct Contact Form -->
    <div class="glass-card p-4">
        <h5 class="fw-bold mb-1">
            <i class="bi bi-send-check me-2 text-primary"></i>Kirim Pesan Langsung
        </h5>
        <p class="text-muted small mb-4">
            Isi form di bawah ini dan saya akan segera merespons pesan Anda.
        </p>
        <form id="contactForm" novalidate>
            <div class="row g-3">
                <div class="col-md-6">
                    <label for="contactName" class="form-label fw-semibold small">Nama Lengkap</label>
                    <input type="text" id="contactName" class="form-control glass-input"
                           placeholder="Nama Anda" required>
                </div>
                <div class="col-md-6">
                    <label for="contactEmail" class="form-label fw-semibold small">Alamat Email</label>
                    <input type="email" id="contactEmail" class="form-control glass-input"
                           placeholder="email@example.com" required>
                </div>
                <div class="col-12">
                    <label for="contactMsg" class="form-label fw-semibold small">Pesan</label>
                    <textarea id="contactMsg" class="form-control glass-input" rows="4"
                              placeholder="Tulis pesan Anda di sini..." required></textarea>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary rounded-pill px-4" id="contactSubmit">
                        <i class="bi bi-send me-2"></i>Kirim Pesan
                    </button>
                </div>
            </div>
        </form>
    </div>

</div>

<script>
document.getElementById('contactForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const btn   = document.getElementById('contactSubmit');
    const name  = document.getElementById('contactName').value.trim();
    const email = document.getElementById('contactEmail').value.trim();
    const msg   = document.getElementById('contactMsg').value.trim();

    if (!name || !email || !msg) {
        showToast('Harap isi semua field!', 'warning');
        return;
    }

    btn.disabled  = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Mengirim...';

    setTimeout(() => {
        btn.disabled  = false;
        btn.innerHTML = '<i class="bi bi-send me-2"></i>Kirim Pesan';
        this.reset();
        showToast('Pesan berhasil dikirim! Terima kasih telah menghubungi Ugroseno Dwi Prakastyo.', 'success');
    }, 1500);
});
</script>
