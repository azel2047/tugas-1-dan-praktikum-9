<?php
$profileFotoUrl = null;
if (isset($user) && $user) {
    $profileUser = dbFetchOne('SELECT foto_profil FROM users WHERE id = ? LIMIT 1', 'i', [$user['id']]);
    if ($profileUser && $profileUser['foto_profil'] && file_exists(UPLOAD_DIR . $profileUser['foto_profil'])) {
        $profileFotoUrl = UPLOAD_URL . $profileUser['foto_profil'];
    }
} else {
    // Ambil foto admin untuk tampilan publik
    $profileUser = dbFetchOne("SELECT foto_profil FROM users WHERE role='admin' ORDER BY id ASC LIMIT 1");
    if ($profileUser && $profileUser['foto_profil'] && file_exists(UPLOAD_DIR . $profileUser['foto_profil'])) {
        $profileFotoUrl = UPLOAD_URL . $profileUser['foto_profil'];
    }
}
?>
<div class="page-home">

    <!-- Welcome Banner -->
    <div class="d-flex align-items-center justify-content-between mb-4">
        <div>
            <h1 class="h3 fw-bold mb-1">Selamat Datang! <span class="wave">👋</span></h1>
            <p class="text-muted mb-0">Senang bertemu Anda di halaman pribadi saya.</p>
        </div>
        <?php if (isset($user) && $user): ?>
        <div class="d-none d-md-block">
            <span class="badge glass-badge px-3 py-2 rounded-pill">
                <i class="bi bi-shield-check me-1 text-success"></i>
                Login sebagai <strong><?= htmlspecialchars($user['nama_lengkap'] ?? 'Pengguna') ?></strong>
            </span>
        </div>
        <?php endif; ?>
    </div>

    <!-- Profile Card Horizontal -->
    <div class="card glass-card border-0 mb-4 profile-card">
        <div class="row g-0">

            <!-- Photo Column -->
            <div class="col-md-4 col-lg-3">
                <div class="profile-photo-wrapper d-flex align-items-center justify-content-center h-100 p-4">
                    <div class="profile-photo-circle">
                        <?php if ($profileFotoUrl): ?>
                            <img src="<?= htmlspecialchars($profileFotoUrl) ?>" alt="Foto Profil Ugroseno Dwi Prakastyo">
                        <?php else: ?>
                            <i class="bi bi-person-fill"></i>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Info Column -->
            <div class="col-md-8 col-lg-9">
                <div class="card-body p-4">

                    <!-- Name & Badge -->
                    <div class="d-flex align-items-start justify-content-between flex-wrap gap-2 mb-3">
                        <div>
                            <h2 class="card-title h4 fw-bold mb-1">Ugroseno Dwi Prakastyo</h2>
                            <p class="text-primary fw-semibold mb-0">
                                <i class="bi bi-code-slash me-1"></i>Full-Stack Web Developer
                            </p>
                        </div>
                        <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3 py-2">
                            <i class="bi bi-circle-fill me-1" style="font-size:.5rem;"></i>Available for work
                        </span>
                    </div>

                    <!-- Bio -->
                    <p class="card-text text-muted mb-4">
                        Halo, nama saya <strong>Ugroseno Dwi Prakastyo</strong> — seorang web developer yang bersemangat
                        dalam membangun aplikasi web modern. Saya fokus pada user experience yang intuitif, kode yang
                        bersih, dan solusi yang efektif. Berpengalaman dalam PHP native, MySQL, JavaScript, dan Bootstrap.
                        Selalu antusias untuk terus belajar dan berkembang bersama tim.
                    </p>

                    <!-- Info Grid -->
                    <div class="row g-3 mb-4">
                        <div class="col-sm-6">
                            <div class="info-item d-flex align-items-center gap-2">
                                <div class="info-icon"><i class="bi bi-geo-alt-fill"></i></div>
                                <div>
                                    <div class="text-muted small">Lokasi</div>
                                    <div class="fw-semibold small">Indonesia</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="info-item d-flex align-items-center gap-2">
                                <div class="info-icon"><i class="bi bi-briefcase-fill"></i></div>
                                <div>
                                    <div class="text-muted small">Status</div>
                                    <div class="fw-semibold small">Open to Opportunities</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="info-item d-flex align-items-center gap-2">
                                <div class="info-icon"><i class="bi bi-mortarboard-fill"></i></div>
                                <div>
                                    <div class="text-muted small">Pendidikan</div>
                                    <div class="fw-semibold small">Teknik Informatika, S1</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="info-item d-flex align-items-center gap-2">
                                <div class="info-icon"><i class="bi bi-envelope-fill"></i></div>
                                <div>
                                    <div class="text-muted small">Email</div>
                                    <div class="fw-semibold small">azelxiteer@gmail.com</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Skills -->
                    <div class="mb-4">
                        <p class="fw-semibold small text-muted mb-2">Keahlian Utama:</p>
                        <div class="d-flex flex-wrap gap-2">
                            <?php
                            $skills = ['PHP', 'MySQL', 'JavaScript', 'Bootstrap 5', 'HTML5', 'CSS3', 'Laravel', 'REST API'];
                            foreach ($skills as $skill):
                            ?>
                                <span class="badge skill-badge"><?= $skill ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="d-flex flex-wrap gap-2">
                        <a href="<?= BASE_URL ?>/?page=contact" class="btn btn-primary rounded-pill px-4">
                            <i class="bi bi-send me-2"></i>Hubungi Saya
                        </a>
                        <a href="<?= BASE_URL ?>/?page=my_studies" class="btn btn-outline-primary rounded-pill px-4">
                            <i class="bi bi-mortarboard me-2"></i>Riwayat Studi
                        </a>
                        <a href="<?= BASE_URL ?>/?page=about" class="btn btn-outline-secondary rounded-pill px-4">
                            <i class="bi bi-info-circle me-2"></i>Tentang Saya
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <?php
    $totalStudies = dbFetchOne('SELECT COUNT(*) as cnt FROM studies')['cnt'] ?? 0;
    $totalLevel   = dbFetchOne('SELECT COUNT(*) as cnt FROM level')['cnt']   ?? 0;
    $latestStudy  = dbFetchOne(
        'SELECT s.nama, l.nama AS level FROM studies s
         JOIN level l ON s.idlevel = l.id
         ORDER BY s.tahun_lulus DESC LIMIT 1'
    );
    ?>
    <div class="row g-3">
        <div class="col-sm-4">
            <div class="glass-card p-3 text-center stat-card">
                <div class="stat-number text-primary"><?= $totalStudies ?></div>
                <div class="text-muted small">Riwayat Pendidikan</div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="glass-card p-3 text-center stat-card">
                <div class="stat-number text-success"><?= $totalLevel ?></div>
                <div class="text-muted small">Level Pendidikan</div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="glass-card p-3 text-center stat-card">
                <div class="stat-number text-warning" style="font-size:1.1rem;">
                    <?= $latestStudy ? htmlspecialchars($latestStudy['level']) : '—' ?>
                </div>
                <div class="text-muted small">Pendidikan Terakhir</div>
            </div>
        </div>
    </div>

</div>
