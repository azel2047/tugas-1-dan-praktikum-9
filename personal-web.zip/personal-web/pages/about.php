<?php
?>
<div class="page-about">

    <!-- Page Header -->
    <div class="mb-4">
        <h1 class="h3 fw-bold mb-1">Tentang Saya</h1>
        <p class="text-muted mb-0">
            Kenali saya lebih dekat — hobi, makanan favorit, dan pengalaman organisasi.
        </p>
    </div>

    <!-- Summary Banner -->
    <div class="glass-card p-4 mb-4 d-flex align-items-center gap-4">
        <div class="about-avatar flex-shrink-0">
            <i class="bi bi-person-heart"></i>
        </div>
        <div>
            <h5 class="fw-bold mb-1">Ugroseno Dwi Prakastyo</h5>
            <p class="text-muted small mb-3">
                Seorang yang antusias dalam dunia teknologi dan selalu berusaha untuk berkembang setiap harinya.
                Saya percaya bahwa teknologi adalah alat terbaik untuk menciptakan dampak positif bagi masyarakat.
            </p>
            <div class="d-flex flex-wrap gap-2">
                <span class="badge bg-primary-subtle text-primary border border-primary-subtle rounded-pill px-3">
                    <i class="bi bi-geo me-1"></i>Indonesia
                </span>
                <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3">
                    <i class="bi bi-mortarboard me-1"></i>S1 Teknik Informatika
                </span>
                <span class="badge bg-warning-subtle text-warning border border-warning-subtle rounded-pill px-3">
                    <i class="bi bi-code me-1"></i>Full-Stack Developer
                </span>
            </div>
        </div>
    </div>

    <!-- Accordion -->
    <div class="accordion accordion-flush glass-accordion" id="aboutAccordion">

        <!-- 1. Hobbies -->
        <div class="accordion-item glass-accordion-item mb-3">
            <h2 class="accordion-header" id="headingHobby">
                <button class="accordion-button fw-semibold" type="button"
                        data-bs-toggle="collapse" data-bs-target="#collapseHobby"
                        aria-expanded="true" aria-controls="collapseHobby">
                    <i class="bi bi-heart-fill text-danger me-2"></i>Hobi &amp; Minat
                </button>
            </h2>
            <div id="collapseHobby" class="accordion-collapse collapse show"
                 aria-labelledby="headingHobby" data-bs-parent="#aboutAccordion">
                <div class="accordion-body">
                    <div class="row g-3">
                        <?php
                        $hobbies = [
                            ['icon' => 'bi-laptop-fill',       'color' => 'primary',   'title' => 'Coding',        'desc' => 'Membangun aplikasi web yang bermanfaat dan scalable'],
                            ['icon' => 'bi-controller',        'color' => 'success',   'title' => 'Gaming',        'desc' => 'Menikmati game strategi & RPG di waktu senggang'],
                            ['icon' => 'bi-music-note-beamed', 'color' => 'warning',   'title' => 'Musik',         'desc' => 'Mendengarkan berbagai genre dari jazz hingga pop'],
                            ['icon' => 'bi-camera-fill',       'color' => 'info',      'title' => 'Fotografi',     'desc' => 'Mengabadikan momen indah dalam kehidupan sehari-hari'],
                            ['icon' => 'bi-book-fill',         'color' => 'secondary', 'title' => 'Membaca',       'desc' => 'Buku teknologi, fiksi ilmiah, dan pengembangan diri'],
                            ['icon' => 'bi-bicycle',           'color' => 'danger',    'title' => 'Bersepeda',     'desc' => 'Olahraga pagi untuk menjaga kesehatan dan stamina'],
                        ];
                        foreach ($hobbies as $h): ?>
                        <div class="col-sm-6 col-md-4">
                            <div class="hobby-card d-flex align-items-center gap-3 p-3 rounded-3">
                                <div class="hobby-icon text-<?= $h['color'] ?>">
                                    <i class="bi <?= $h['icon'] ?>"></i>
                                </div>
                                <div>
                                    <div class="fw-semibold small"><?= $h['title'] ?></div>
                                    <div class="text-muted" style="font-size:.75rem;"><?= $h['desc'] ?></div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- 2. Menu Favorit -->
        <div class="accordion-item glass-accordion-item mb-3">
            <h2 class="accordion-header" id="headingFood">
                <button class="accordion-button collapsed fw-semibold" type="button"
                        data-bs-toggle="collapse" data-bs-target="#collapseFood"
                        aria-expanded="false" aria-controls="collapseFood">
                    <i class="bi bi-cup-hot-fill text-warning me-2"></i>Menu Favorit
                </button>
            </h2>
            <div id="collapseFood" class="accordion-collapse collapse"
                 aria-labelledby="headingFood" data-bs-parent="#aboutAccordion">
                <div class="accordion-body">
                    <p class="text-muted small mb-4">
                        Makanan dan minuman yang selalu saya nikmati setiap harinya.
                    </p>
                    <div class="row g-3">
                        <?php
                        $foods = [
                            ['emoji' => '🍜', 'name' => 'Mie Ayam Bakso',      'cat' => 'Makanan Utama',  'desc' => 'Hidangan favorit sejak kecil'],
                            ['emoji' => '🍛', 'name' => 'Nasi Goreng Spesial', 'cat' => 'Makanan Utama',  'desc' => 'Sempurna untuk makan malam'],
                            ['emoji' => '🍦', 'name' => 'Es Krim Coklat',      'cat' => 'Dessert',        'desc' => 'Penutup terbaik setelah makan'],
                            ['emoji' => '☕', 'name' => 'Kopi Susu',           'cat' => 'Minuman',        'desc' => 'Pendamping setia saat coding'],
                            ['emoji' => '🍱', 'name' => 'Sushi',               'cat' => 'Internasional',  'desc' => 'Sesekali menikmati masakan Jepang'],
                            ['emoji' => '🥤', 'name' => 'Teh Tarik',           'cat' => 'Minuman',        'desc' => 'Menyegarkan di sore hari'],
                        ];
                        foreach ($foods as $f): ?>
                        <div class="col-sm-6 col-md-4">
                            <div class="food-card p-3 rounded-3 text-center">
                                <div class="food-emoji"><?= $f['emoji'] ?></div>
                                <div class="fw-semibold small mt-2"><?= $f['name'] ?></div>
                                <div class="text-muted" style="font-size:.75rem;"><?= $f['desc'] ?></div>
                                <span class="badge bg-secondary-subtle text-secondary rounded-pill mt-1 px-2"
                                      style="font-size:.65rem;"><?= $f['cat'] ?></span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- 3. Pengalaman Organisasi -->
        <div class="accordion-item glass-accordion-item">
            <h2 class="accordion-header" id="headingOrg">
                <button class="accordion-button collapsed fw-semibold" type="button"
                        data-bs-toggle="collapse" data-bs-target="#collapseOrg"
                        aria-expanded="false" aria-controls="collapseOrg">
                    <i class="bi bi-people-fill text-primary me-2"></i>Pengalaman Organisasi
                </button>
            </h2>
            <div id="collapseOrg" class="accordion-collapse collapse"
                 aria-labelledby="headingOrg" data-bs-parent="#aboutAccordion">
                <div class="accordion-body">
                    <div class="timeline">
                        <?php
                        $orgs = [
                            [
                                'year' => '2022–2023',
                                'org'  => 'Himpunan Mahasiswa Informatika',
                                'role' => 'Ketua Divisi Teknologi',
                                'desc' => 'Memimpin tim dalam pengembangan website organisasi dan mengadakan workshop pemrograman untuk anggota baru.',
                            ],
                            [
                                'year' => '2021–2022',
                                'org'  => 'UKM Robotika Universitas',
                                'role' => 'Anggota Aktif',
                                'desc' => 'Berpartisipasi dalam kompetisi robotika regional dan mengembangkan prototype robot berbasis Arduino.',
                            ],
                            [
                                'year' => '2019–2020',
                                'org'  => 'OSIS SMA',
                                'role' => 'Sekretaris Umum',
                                'desc' => 'Bertanggung jawab atas administrasi organisasi dan koordinasi seluruh kegiatan sekolah.',
                            ],
                            [
                                'year' => '2019',
                                'org'  => 'Paskibra Kabupaten',
                                'role' => 'Anggota Pasukan',
                                'desc' => 'Terpilih mewakili sekolah dalam upacara pengibaran bendera tingkat kabupaten.',
                            ],
                        ];
                        foreach ($orgs as $i => $org): ?>
                        <div class="timeline-item <?= $i < count($orgs) - 1 ? 'mb-4' : '' ?>">
                            <div class="timeline-dot"></div>
                            <div class="timeline-content glass-card p-3 ms-4">
                                <div class="d-flex justify-content-between align-items-start flex-wrap gap-1 mb-1">
                                    <h6 class="fw-bold mb-0"><?= $org['org'] ?></h6>
                                    <span class="badge bg-primary-subtle text-primary rounded-pill px-2"
                                          style="font-size:.7rem;"><?= $org['year'] ?></span>
                                </div>
                                <p class="text-primary small fw-semibold mb-1"><?= $org['role'] ?></p>
                                <p class="text-muted small mb-0"><?= $org['desc'] ?></p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
