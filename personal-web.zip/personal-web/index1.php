<?php
session_start();

/**
 * SIMULASI DATABASE MENGGUNAKAN SESSION
 * Agar kode ini bisa langsung dijalankan tanpa setup MySQL terlebih dahulu,
 * saya menggunakan Session untuk menyimpan data CRUD. 
 * Dalam produksi, bagian ini diganti dengan query SQL.
 */

// Inisialisasi Data Default jika belum ada
if (!isset($_SESSION['levels'])) {
    $_SESSION['levels'] = [
        ['id' => 1, 'nama' => 'TK'],
        ['id' => 2, 'nama' => 'SD'],
        ['id' => 3, 'nama' => 'SMP'],
        ['id' => 4, 'nama' => 'SMA'],
        ['id' => 5, 'nama' => 'Universitas']
    ];
}

if (!isset($_SESSION['studies'])) {
    $_SESSION['studies'] = [
        [
            'id' => 1, 
            'nama' => 'STT Terpadu Nurul Fikri', 
            'id_level' => 5, 
            'keterangan' => 'S1 Teknik Informatika - Semester 2', 
            'tahun_lulus' => '2028 (Expected)',
            'foto' => 'https://images.unsplash.com/photo-1562774053-701939374585?w=400'
        ],
        [
            'id' => 2, 
            'nama' => 'SMK Raflesia Depok', 
            'id_level' => 4, 
            'keterangan' => 'Keahlian Teknik Komputer & Jaringan', 
            'tahun_lulus' => '2023',
            'foto' => 'https://images.unsplash.com/photo-1523050853063-bd388f9c7d13?w=400'
        ]
    ];
}

// Logic Auth Sederhana
$user = isset($_SESSION['user']) ? $_SESSION['user'] : null;

if (isset($_GET['action'])) {
    // LOGIN
    if ($_GET['action'] == 'login' && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $_SESSION['user'] = ['username' => 'Ugroseno', 'role' => 'Administrator'];
        header("Location: index.php");
        exit();
    }
    // LOGOUT
    if ($_GET['action'] == 'logout') {
        unset($_SESSION['user']);
        header("Location: index.php");
        exit();
    }
    // CRUD: Add Study
    if ($_GET['action'] == 'add_study' && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $new_id = end($_SESSION['studies'])['id'] + 1;
        $_SESSION['studies'][] = [
            'id' => $new_id,
            'nama' => $_POST['nama'],
            'id_level' => $_POST['id_level'],
            'keterangan' => $_POST['keterangan'],
            'tahun_lulus' => $_POST['tahun_lulus'],
            'foto' => 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=400'
        ];
        header("Location: index.php?page=studies");
        exit();
    }
    // CRUD: Delete Study
    if ($_GET['action'] == 'delete_study' && isset($_GET['id'])) {
        foreach($_SESSION['studies'] as $key => $val) {
            if ($val['id'] == $_GET['id']) unset($_SESSION['studies'][$key]);
        }
        header("Location: index.php?page=studies");
        exit();
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 'home';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ugroseno Dwi Prakastyo | Portfolio</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --glass-bg: rgba(255, 255, 255, 0.08);
            --glass-border: rgba(255, 255, 255, 0.15);
            --accent-blue: #60a5fa;
            --accent-purple: #a855f7;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #030712;
            color: #f3f4f6;
            margin: 0;
            overflow-x: hidden;
            min-height: 100vh;
        }

        /* Aurora Background */
        .aurora-bg {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            z-index: -1;
            overflow: hidden;
            background: radial-gradient(circle at 50% 50%, #030712, #000);
        }

        .aurora-blob {
            position: absolute;
            width: 600px; height: 600px;
            filter: blur(100px);
            border-radius: 50%;
            opacity: 0.4;
            mix-blend-mode: screen;
            animation: move 20s infinite alternate;
        }
        .blob-1 { background: var(--accent-blue); top: -10%; left: -10%; }
        .blob-2 { background: var(--accent-purple); bottom: -10%; right: -10%; animation-delay: -5s; }
        .blob-3 { background: #3b82f6; top: 40%; left: 30%; animation-delay: -10s; }

        @keyframes move {
            from { transform: translate(0, 0) scale(1); }
            to { transform: translate(100px, 100px) scale(1.2); }
        }

        /* Glassmorphism Components */
        .glass-card {
            background: var(--glass-bg);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid var(--glass-border);
            border-radius: 24px;
            padding: 2rem;
            transition: all 0.3s ease;
        }

        .glass-card:hover {
            border-color: rgba(255, 255, 255, 0.3);
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        }

        /* Loading Screen */
        #loader {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: #000;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        #loader-text {
            font-size: 2.5rem;
            font-weight: 800;
            color: white;
            text-align: center;
        }

        .progress-bar-container {
            width: 200px;
            height: 2px;
            background: rgba(255,255,255,0.1);
            margin-top: 2rem;
            border-radius: 10px;
            overflow: hidden;
        }

        #progress-val {
            width: 0%;
            height: 100%;
            background: white;
        }

        /* Navbar */
        .nav-container {
            padding-top: 2rem;
        }

        .navbar-custom {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid var(--glass-border);
            border-radius: 50px;
            padding: 0.5rem 1.5rem;
        }

        .nav-link {
            color: rgba(255,255,255,0.7) !important;
            font-weight: 500;
            margin: 0 0.5rem;
            transition: 0.3s;
        }

        .nav-link:hover, .nav-link.active {
            color: white !important;
        }

        /* Horizontal Profile Card */
        .profile-card {
            display: flex;
            align-items: center;
            gap: 2rem;
        }

        .profile-img {
            width: 180px;
            height: 180px;
            border-radius: 20px;
            object-fit: cover;
            border: 4px solid var(--glass-border);
        }

        /* Accordion Custom */
        .accordion-item {
            background: transparent !important;
            border: none !important;
            border-bottom: 1px solid var(--glass-border) !important;
            margin-bottom: 0.5rem;
        }

        .accordion-button {
            background: transparent !important;
            color: white !important;
            box-shadow: none !important;
            padding: 1.5rem 0;
            font-weight: 600;
        }

        .accordion-button::after {
            filter: invert(1);
        }

        .accordion-body {
            color: rgba(255,255,255,0.7);
            padding: 1rem 0;
        }

        /* Contact Cards */
        .contact-card {
            text-align: center;
            padding: 1.5rem;
        }
        .contact-card i {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            background: linear-gradient(to bottom right, var(--accent-blue), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .btn-custom {
            background: white;
            color: black;
            border-radius: 50px;
            padding: 0.6rem 1.5rem;
            font-weight: 600;
            border: none;
            transition: 0.3s;
        }

        .btn-custom:hover {
            transform: translateY(-3px);
            background: #e5e5e5;
        }

        /* Section Transition */
        section {
            display: none;
            opacity: 0;
        }
        section.active {
            display: block;
        }

        /* CRUD Table */
        .table-custom {
            color: white;
        }
        .table-custom thead {
            border-bottom: 2px solid var(--glass-border);
        }
        .table-custom td, .table-custom th {
            padding: 1rem;
            border-color: var(--glass-border);
        }

        .badge-role {
            background: rgba(96, 165, 250, 0.2);
            color: var(--accent-blue);
            font-size: 0.75rem;
            padding: 0.3rem 0.8rem;
            border-radius: 50px;
        }
    </style>
</head>
<body>

    <!-- Loading Screen -->
    <div id="loader">
        <div id="loader-text">Hello</div>
        <div class="progress-bar-container">
            <div id="progress-val"></div>
        </div>
    </div>

    <!-- Background -->
    <div class="aurora-bg">
        <div class="aurora-blob blob-1"></div>
        <div class="aurora-blob blob-2"></div>
        <div class="aurora-blob blob-3"></div>
    </div>

    <!-- Navigation -->
    <div class="container nav-container">
        <nav class="navbar navbar-expand-lg navbar-dark navbar-custom mx-auto">
            <div class="container-fluid">
                <a class="navbar-brand fw-bold" href="?page=home">U.D.P</a>
                <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto align-items-center">
                        <li class="nav-item"><a class="nav-link <?= $page == 'home' ? 'active' : '' ?>" href="?page=home">Home</a></li>
                        <li class="nav-item"><a class="nav-link <?= $page == 'about' ? 'active' : '' ?>" href="?page=about">About</a></li>
                        <li class="nav-item"><a class="nav-link <?= $page == 'contact' ? 'active' : '' ?>" href="?page=contact">Contact</a></li>
                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">My Studies</a>
                            <ul class="dropdown-menu dropdown-menu-dark glass-card p-2">
                                <li><a class="dropdown-item rounded-3" href="?page=levels">Levels</a></li>
                                <li><a class="dropdown-item rounded-3" href="?page=studies">Studies</a></li>
                            </ul>
                        </li>

                        <?php if($user): ?>
                            <li class="nav-item ms-lg-4 d-flex align-items-center gap-2">
                                <span class="small opacity-75">Hi, <?= $user['username'] ?> <span class="badge-role"><?= $user['role'] ?></span></span>
                                <a href="?action=logout" class="btn btn-sm btn-outline-danger rounded-pill border-0"><i class="fas fa-sign-out-alt"></i></a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item ms-lg-4">
                                <button class="btn btn-custom" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </div>

    <!-- Main Content -->
    <main class="container my-5 pb-5">
        
        <!-- HOME PAGE -->
        <section id="home" class="<?= $page == 'home' ? 'active' : '' ?>">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="glass-card profile-card">
                        <img src="https://ui-avatars.com/api/?name=Ugroseno+Dwi+Prakastyo&background=0D8ABC&color=fff&size=512" alt="Profile" class="profile-img">
                        <div>
                            <span class="badge-role mb-2 d-inline-block">Fullstack Developer</span>
                            <h1 class="display-5 fw-bold mb-3">Ugroseno Dwi Prakastyo</h1>
                            <p class="lead opacity-75 mb-4">
                                Mahasiswa Teknik Informatika yang berpengalaman sejak 2022 dalam membangun solusi digital skalabel. 
                                Ahli dalam merancang UI premium (Glassmorphism) dan integrasi AI.
                            </p>
                            <div class="d-flex gap-3">
                                <a href="?page=contact" class="btn btn-custom">Mari Berkolaborasi</a>
                                <a href="https://github.com/azel2047" target="_blank" class="btn btn-outline-light rounded-pill px-4">GitHub</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ABOUT ME PAGE -->
        <section id="about" class="<?= $page == 'about' ? 'active' : '' ?>">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h2 class="fw-bold mb-4">About Me</h2>
                    <div class="accordion" id="aboutAccordion">
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseHobby">
                                    <i class="fas fa-heart me-3 text-danger"></i> Minat & Hobi
                                </button>
                            </h2>
                            <div id="collapseHobby" class="accordion-collapse collapse show" data-bs-parent="#aboutAccordion">
                                <div class="accordion-body">
                                    Eksplorasi AI & Keamanan Siber, Analisis Pasar Finansial (Trading), Komunitas Digital, dan Penikmat Konten Multimedia.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFood">
                                    <i class="fas fa-utensils me-3 text-warning"></i> Tech Stack Favorit
                                </button>
                            </h2>
                            <div id="collapseFood" class="accordion-collapse collapse" data-bs-parent="#aboutAccordion">
                                <div class="accordion-body">
                                    JavaScript (Next.js/Node.js), PHP (Native/Framework), Flutter untuk Mobile, dan Dart. Suka bereksperimen dengan desain Glassmorphism dan Aurora Effects.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOrg">
                                    <i class="fas fa-users me-3 text-info"></i> Pengalaman Proyek
                                </button>
                            </h2>
                            <div id="collapseOrg" class="accordion-collapse collapse" data-bs-parent="#aboutAccordion">
                                <div class="accordion-body">
                                    <ul class="mb-0">
                                        <li><strong>Algorithmic Trading Developer:</strong> Merancang logika Expert Advisor (EA) otomatis.</li>
                                        <li><strong>Aplikasi Penerjemah Bahasa Isyarat:</strong> Menggunakan Flutter untuk membantu komunikasi disabilitas.</li>
                                        <li><strong>DumnProject:</strong> Deployment aplikasi pada platform Vercel & Railway.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- CONTACT PAGE -->
        <section id="contact" class="<?= $page == 'contact' ? 'active' : '' ?>">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <h2 class="fw-bold mb-4 text-center">Hubungi Saya</h2>
                    <div class="row row-cols-1 row-cols-md-3 g-4">
                        <div class="col">
                            <div class="glass-card contact-card h-100">
                                <i class="fab fa-linkedin"></i>
                                <h5>LinkedIn</h5>
                                <p class="small opacity-50">Koneksi Profesional</p>
                                <a href="#" class="btn btn-sm btn-outline-light rounded-pill w-100">Kunjungi</a>
                            </div>
                        </div>
                        <div class="col">
                            <div class="glass-card contact-card h-100">
                                <i class="fab fa-github"></i>
                                <h5>GitHub</h5>
                                <p class="small opacity-50">Source Code & Proyek</p>
                                <a href="https://github.com/azel2047" target="_blank" class="btn btn-sm btn-outline-light rounded-pill w-100">Lihat Repo</a>
                            </div>
                        </div>
                        <div class="col">
                            <div class="glass-card contact-card h-100">
                                <i class="fas fa-envelope"></i>
                                <h5>Email</h5>
                                <p class="small opacity-50">azelxiteer@gmail.com</p>
                                <a href="mailto:azelxiteer@gmail.com" class="btn btn-sm btn-outline-light rounded-pill w-100">Kirim Pesan</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- STUDIES PAGE -->
        <section id="studies" class="<?= $page == 'studies' ? 'active' : '' ?>">
            <div class="glass-card">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="fw-bold mb-0">Riwayat Pendidikan</h2>
                    <?php if($user): ?>
                        <button class="btn btn-custom" data-bs-toggle="modal" data-bs-target="#addStudyModal"><i class="fas fa-plus me-2"></i> Tambah Studi</button>
                    <?php endif; ?>
                </div>

                <?php if(!$user): ?>
                    <div class="alert border-0 bg-warning bg-opacity-10 text-warning rounded-4 mb-4">
                        <i class="fas fa-lock me-2"></i> Anda harus login untuk menambah atau menghapus data pendidikan.
                    </div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-custom align-middle">
                        <thead>
                            <tr>
                                <th>Institusi</th>
                                <th>Level</th>
                                <th>Keterangan</th>
                                <th>Lulus</th>
                                <?php if($user): ?><th>Aksi</th><?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($_SESSION['studies'] as $s): ?>
                                <?php 
                                    $lvl_name = '';
                                    foreach($_SESSION['levels'] as $l) if($l['id'] == $s['id_level']) $lvl_name = $l['nama'];
                                ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center gap-3">
                                            <img src="<?= $s['foto'] ?>" width="40" height="40" class="rounded-circle object-fit-cover" alt="icon">
                                            <strong><?= $s['nama'] ?></strong>
                                        </div>
                                    </td>
                                    <td><span class="badge-role"><?= $lvl_name ?></span></td>
                                    <td><?= $s['keterangan'] ?></td>
                                    <td><?= $s['tahun_lulus'] ?></td>
                                    <?php if($user): ?>
                                    <td>
                                        <a href="?action=delete_study&id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-danger border-0"><i class="fas fa-trash"></i></a>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

        <!-- LEVELS PAGE -->
        <section id="levels" class="<?= $page == 'levels' ? 'active' : '' ?>">
            <div class="glass-card col-lg-6 mx-auto">
                <h2 class="fw-bold mb-4">Tingkat Pendidikan</h2>
                <ul class="list-group list-group-flush bg-transparent">
                    <?php foreach($_SESSION['levels'] as $l): ?>
                        <li class="list-group-item bg-transparent text-white border-opacity-10 d-flex justify-content-between align-items-center">
                            <span><?= $l['nama'] ?></span>
                            <span class="opacity-25 small">ID: <?= $l['id'] ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </section>

    </main>

    <!-- Modals -->
    <!-- Login Modal -->
    <div class="modal fade" id="loginModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content glass-card border-0 p-3">
                <div class="modal-header border-0">
                    <h5 class="modal-title fw-bold">Login Admin</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form action="index.php?action=login" method="POST">
                        <div class="mb-3">
                            <label class="form-label opacity-75">Username</label>
                            <input type="text" class="form-control bg-dark bg-opacity-50 border-secondary text-white" value="admin" readonly>
                        </div>
                        <div class="mb-4">
                            <label class="form-label opacity-75">Password</label>
                            <input type="password" class="form-control bg-dark bg-opacity-50 border-secondary text-white" value="password" readonly>
                        </div>
                        <button type="submit" class="btn btn-custom w-100">Masuk Sekarang</button>
                        <p class="text-center small opacity-50 mt-3">Gunakan kredensial default untuk demo.</p>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Study Modal -->
    <div class="modal fade" id="addStudyModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content glass-card border-0 p-3">
                <div class="modal-header border-0">
                    <h5 class="modal-title fw-bold">Tambah Riwayat Studi</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form action="index.php?action=add_study" method="POST">
                        <div class="mb-3">
                            <label class="form-label">Nama Sekolah/Instansi</label>
                            <input type="text" name="nama" class="form-control bg-dark text-white border-secondary" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Level</label>
                            <select name="id_level" class="form-select bg-dark text-white border-secondary">
                                <?php foreach($_SESSION['levels'] as $l): ?>
                                    <option value="<?= $l['id'] ?>"><?= $l['nama'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Keterangan</label>
                            <input type="text" name="keterangan" class="form-control bg-dark text-white border-secondary">
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Tahun Lulus</label>
                            <input type="text" name="tahun_lulus" class="form-control bg-dark text-white border-secondary">
                        </div>
                        <button type="submit" class="btn btn-custom w-100">Simpan Data</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- GSAP & Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>

    <script>
        // Animasi Loading Screen (iOS Style)
        window.addEventListener('load', () => {
            const greetings = ["Hello", "Halo", "Namaste", "Konnichiwa", "Bonjour", "Ciao", "Salam"];
            let i = 0;
            const loaderText = document.getElementById('loader-text');
            const progressVal = document.getElementById('progress-val');

            const textInterval = setInterval(() => {
                loaderText.innerText = greetings[i];
                i++;
                if (i >= greetings.length) i = 0;
            }, 150);

            gsap.to(progressVal, {
                width: '100%',
                duration: 2.5,
                ease: 'power2.inOut',
                onComplete: () => {
                    clearInterval(textInterval);
                    loaderText.innerText = "Welcome";
                    
                    gsap.to('#loader', {
                        opacity: 0,
                        duration: 0.8,
                        delay: 0.3,
                        onComplete: () => {
                            document.getElementById('loader').style.display = 'none';
                            revealContent();
                        }
                    });
                }
            });
        });

        // Animasi Reveal Halaman Utama
        function revealContent() {
            gsap.from('.nav-container', { y: -50, opacity: 0, duration: 1, ease: 'back.out' });
            
            const activeSection = document.querySelector('section.active');
            if (activeSection) {
                gsap.to(activeSection, { 
                    display: 'block', 
                    opacity: 1, 
                    y: 0, 
                    duration: 1, 
                    delay: 0.5,
                    startAt: { y: 30 }
                });
            }
        }

        // Transisi antar halaman (SPA Simulation)
        document.querySelectorAll('.nav-link, .navbar-brand, .dropdown-item').forEach(link => {
            link.addEventListener('click', (e) => {
                const url = new URL(link.href);
                const pageParam = url.searchParams.get('page');
                
                // Jika ganti halaman di domain yang sama (simulasi SPA)
                if (pageParam) {
                    // Hanya lakukan animasi jika di dalam halaman yang sama tanpa reload PHP
                    // Namun karena ini PHP Native, navigasi biasanya memicu reload.
                    // Animasi masuk akan dipicu oleh script di atas saat load.
                }
            });
        });

        // Hover Effect untuk Glass Card menggunakan GSAP
        document.querySelectorAll('.glass-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                gsap.to(card, { scale: 1.02, duration: 0.3 });
            });
            card.addEventListener('mouseleave', () => {
                gsap.to(card, { scale: 1, duration: 0.3 });
            });
        });
    </script>
</body>
</html>