<?php
?>
        </main>
        <!-- end dash-content -->

        <!-- Footer Bar -->
        <footer style="padding:12px 24px;border-top:1px solid #e8edf4;background:#fff;
                        display:flex;justify-content:space-between;align-items:center;
                        font-size:.73rem;color:#94a3b8;">
            <span>&copy; <?= date('Y') ?> <?= APP_NAME ?> &mdash; Admin Panel</span>
            <span>Built with <i class="bi bi-heart-fill text-danger" style="font-size:.6rem;"></i> PHP &amp; Bootstrap</span>
        </footer>

    </div><!-- end dash-main -->
</div><!-- end dash-wrapper -->

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Dashboard JS -->
<script>
(function () {
    'use strict';

    /* ---- Mobile Sidebar Toggle ---- */
    const sidebar  = document.getElementById('dashSidebar');
    const overlay  = document.getElementById('dashOverlay');
    const toggle   = document.getElementById('sidebarToggle');

    function openSidebar()  { sidebar.classList.add('open');  overlay.classList.add('show'); }
    function closeSidebar() { sidebar.classList.remove('open'); overlay.classList.remove('show'); }

    if (toggle)  toggle.addEventListener('click', openSidebar);
    if (overlay) overlay.addEventListener('click', closeSidebar);

    /* ---- Auto-dismiss alerts ---- */
    document.querySelectorAll('.alert.alert-success, .alert.alert-info').forEach(function (el) {
        setTimeout(function () {
            const a = bootstrap.Alert.getOrCreateInstance(el);
            if (a) a.close();
        }, 5000);
    });

    /* ---- Tooltips ---- */
    document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (el) {
        new bootstrap.Tooltip(el, { placement: 'bottom', trigger: 'hover' });
    });

    /* ---- Confirm delete (data-confirm attribute) ---- */
    document.querySelectorAll('[data-confirm]').forEach(function (el) {
        el.addEventListener('click', function (e) {
            if (!confirm(el.dataset.confirm)) e.preventDefault();
        });
    });

    /* ---- Delete modal population ---- */
    const deleteModal = document.getElementById('deleteModal');
    if (deleteModal) {
        deleteModal.addEventListener('show.bs.modal', function (e) {
            const btn = e.relatedTarget;
            const nameEl = document.getElementById('deleteItemName');
            const idEl   = document.getElementById('deleteId');
            if (nameEl) nameEl.textContent = btn.dataset.name || '';
            if (idEl)   idEl.value         = btn.dataset.id   || '';
        });
    }

    /* ---- Image preview on file input ---- */
    document.querySelectorAll('input[type="file"]').forEach(function (input) {
        input.addEventListener('change', function () {
            const file = this.files[0];
            const container = document.getElementById('previewContainer');
            const img       = document.getElementById('previewImg');
            if (file && file.type.startsWith('image/') && container && img) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    img.src = e.target.result;
                    container.style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        });
    });

    /* ---- Toggle password visibility ---- */
    const pwToggle = document.getElementById('togglePassword');
    if (pwToggle) {
        pwToggle.addEventListener('click', function () {
            const pw   = document.getElementById('password');
            const icon = document.getElementById('toggleIcon');
            if (!pw) return;
            const hidden = pw.type === 'password';
            pw.type      = hidden ? 'text' : 'password';
            if (icon) icon.className = hidden ? 'bi bi-eye-slash' : 'bi bi-eye';
        });
    }

})();
</script>

</body>
</html>
