<?php

defined('APP_START') or define('APP_START', true);

// Pastikan semua dependency sudah di-load
if (!function_exists('isLoggedIn')) {
    require_once __DIR__ . '/../config/config.php';
    require_once __DIR__ . '/../config/database.php';
    require_once __DIR__ . '/../auth/check_auth.php';
}

startSecureSession();
$user      = currentUser();
$pageTitle = $pageTitle  ?? 'Dashboard';
$breadcrumb = $breadcrumb ?? [];

// Stats untuk sidebar
$totalStudies = dbFetchOne('SELECT COUNT(*) AS c FROM studies')['c'] ?? 0;
$totalLevel   = dbFetchOne('SELECT COUNT(*) AS c FROM level')['c']   ?? 0;

// Current file untuk active nav
$currentFile = basename($_SERVER['PHP_SELF']);
$currentDir  = basename(dirname($_SERVER['PHP_SELF']));

function dashNavItem(string $href, string $icon, string $label, bool $active = false): void {
    $cls = $active ? 'dash-nav-item active' : 'dash-nav-item';
    echo '<a href="' . $href . '" class="' . $cls . '">'
       . '<span class="dash-nav-icon"><i class="bi ' . $icon . '"></i></span>'
       . '<span>' . $label . '</span>'
       . '</a>';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?> — Admin · <?= APP_NAME ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS (Lux) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/lux/bootstrap.min.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Dashboard CSS -->
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/dashboard.css">
</head>
<body class="dashboard-body">

<!-- Mobile overlay -->
<div class="dash-overlay" id="dashOverlay"></div>

<div class="dash-wrapper">

    <!-- ====================================================
         SIDEBAR
         ==================================================== -->
    <aside class="dash-sidebar" id="dashSidebar">

        <!-- Brand -->
        <a class="dash-brand" href="<?= BASE_URL ?>/">
            <div class="dash-brand-icon">
                <i class="bi bi-person-badge-fill"></i>
            </div>
            <div class="dash-brand-text">
                <?= APP_NAME ?>
                <span class="dash-brand-sub">Admin Panel</span>
            </div>
        </a>

        <!-- User Info -->
        <div class="dash-sidebar-user">
            <div class="dash-user-avatar">
                <?= strtoupper(substr($user['nama_lengkap'] ?? 'A', 0, 1)) ?>
            </div>
            <div>
                <div class="dash-user-name"><?= htmlspecialchars($user['nama_lengkap'] ?? '') ?></div>
                <div class="dash-user-role">
                    <span style="width:7px;height:7px;background:#22c55e;border-radius:50%;display:inline-block;margin-right:4px;"></span>
                    <?= ucfirst($user['role'] ?? 'user') ?>
                </div>
            </div>
        </div>

        <!-- Navigation -->
        <nav class="dash-nav">

            <!-- Main -->
            <div class="dash-nav-section">Main</div>

            <?php dashNavItem(
                BASE_URL . '/dashboard/',
                'bi-grid-1x2-fill',
                'Dashboard',
                $currentFile === 'index.php' && $currentDir === 'dashboard'
            ); ?>

            <?php dashNavItem(
                BASE_URL . '/',
                'bi-house-door',
                'Lihat Situs',
                false
            ); ?>

            <!-- Konten -->
            <div class="dash-nav-section">Konten</div>

            <?php dashNavItem(
                BASE_URL . '/dashboard/profile.php',
                'bi-camera-fill',
                'Foto Profil',
                $currentFile === 'profile.php' && $currentDir === 'dashboard'
            ); ?>

            <?php dashNavItem(
                BASE_URL . '/crud/level/index.php',
                'bi-layers',
                'Level Pendidikan',
                $currentDir === 'level'
            ); ?>

            <?php dashNavItem(
                BASE_URL . '/crud/studies/index.php',
                'bi-mortarboard',
                'Data Studies',
                $currentDir === 'studies'
            ); ?>

            <!-- Akun -->
            <div class="dash-nav-section">Akun</div>

            <?php dashNavItem(
                BASE_URL . '/auth/login.php',
                'bi-person-circle',
                'Profil',
                false
            ); ?>

        </nav>

        <!-- Sidebar Footer: Logout -->
        <div class="dash-sidebar-footer">
            <form method="POST" action="<?= BASE_URL ?>/auth/logout.php">
                <?= csrfField() ?>
                <button type="submit" class="dash-nav-item w-100 border-0 text-start"
                        style="background:rgba(239,68,68,.1); color:#fca5a5; border-radius:8px;">
                    <span class="dash-nav-icon"><i class="bi bi-box-arrow-right"></i></span>
                    <span>Logout</span>
                </button>
            </form>
        </div>
    </aside>

    <!-- ====================================================
         MAIN AREA
         ==================================================== -->
    <div class="dash-main">

        <!-- Top Bar -->
        <header class="dash-topbar">
            <!-- Mobile toggle -->
            <button class="dash-mobile-toggle" id="sidebarToggle" aria-label="Toggle sidebar">
                <i class="bi bi-list"></i>
            </button>

            <!-- Page Title + Breadcrumb -->
            <div class="dash-topbar-title">
                <h1><?= htmlspecialchars($pageTitle) ?></h1>
                <?php if (!empty($breadcrumb)): ?>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item">
                            <a href="<?= BASE_URL ?>/dashboard/">Dashboard</a>
                        </li>
                        <?php foreach ($breadcrumb as $i => $crumb): ?>
                            <?php if ($i === count($breadcrumb) - 1): ?>
                                <li class="breadcrumb-item active"><?= htmlspecialchars($crumb['label']) ?></li>
                            <?php else: ?>
                                <li class="breadcrumb-item">
                                    <a href="<?= htmlspecialchars($crumb['url']) ?>"><?= htmlspecialchars($crumb['label']) ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ol>
                </nav>
                <?php endif; ?>
            </div>

            <!-- Right Actions -->
            <div class="dash-topbar-actions">
                <!-- Back to site -->
                <a href="<?= BASE_URL ?>/" class="dash-topbar-btn" title="Lihat Situs" data-bs-toggle="tooltip">
                    <i class="bi bi-arrow-up-right-square"></i>
                </a>

                <!-- Level badge -->
                <a href="<?= BASE_URL ?>/crud/level/create.php" class="dash-topbar-btn" title="Tambah Level">
                    <i class="bi bi-layers"></i>
                </a>

                <!-- Studies add -->
                <a href="<?= BASE_URL ?>/crud/studies/create.php" class="dash-topbar-btn" title="Tambah Studi">
                    <i class="bi bi-plus-lg"></i>
                </a>

                <div style="width:1px; height:24px; background:#e2e8f0;"></div>

                <!-- User Dropdown -->
                <div class="dropdown">
                    <div class="dash-topbar-user" data-bs-toggle="dropdown">
                        <div style="
                            width:30px;height:30px;border-radius:50%;
                            background:linear-gradient(135deg,#3b82f6,#8b5cf6);
                            display:flex;align-items:center;justify-content:center;
                            color:white;font-weight:700;font-size:.78rem;">
                            <?= strtoupper(substr($user['nama_lengkap'] ?? 'A', 0, 1)) ?>
                        </div>
                        <div class="d-none d-sm-block">
                            <div style="font-size:.8rem;font-weight:600;color:#1e293b;line-height:1;">
                                <?= htmlspecialchars($user['nama_lengkap'] ?? '') ?>
                            </div>
                            <div style="font-size:.68rem;color:#94a3b8;">
                                <?= ucfirst($user['role'] ?? '') ?>
                            </div>
                        </div>
                        <i class="bi bi-chevron-down" style="font-size:.65rem;color:#94a3b8;"></i>
                    </div>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm" style="border-radius:12px;border-color:#e2e8f0;font-size:.85rem;min-width:180px;">
                        <li>
                            <div class="px-3 py-2">
                                <div style="font-weight:600;font-size:.82rem;"><?= htmlspecialchars($user['nama_lengkap'] ?? '') ?></div>
                                <div style="color:#94a3b8;font-size:.72rem;">@<?= htmlspecialchars($user['username'] ?? '') ?></div>
                            </div>
                        </li>
                        <li><hr class="dropdown-divider my-1"></li>
                        <li>
                            <a class="dropdown-item" href="<?= BASE_URL ?>/">
                                <i class="bi bi-house me-2"></i>Lihat Situs
                            </a>
                        </li>
                        <li><hr class="dropdown-divider my-1"></li>
                        <li>
                            <form method="POST" action="<?= BASE_URL ?>/auth/logout.php">
                                <?= csrfField() ?>
                                <button type="submit" class="dropdown-item text-danger">
                                    <i class="bi bi-box-arrow-right me-2"></i>Logout
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </header>

        <!-- ================================================
             CONTENT SLOT — diisi oleh halaman masing-masing
             ================================================ -->
        <main class="dash-content">
            <!-- Flash Messages -->
            <?php
            $flashTypes = ['success'=>'success','error'=>'danger','warning'=>'warning','info'=>'info'];
            foreach ($flashTypes as $key => $cls) {
                $msg = getFlash($key);
                if ($msg) {
                    $icons = ['success'=>'check-circle-fill','danger'=>'exclamation-triangle-fill','warning'=>'exclamation-circle-fill','info'=>'info-circle-fill'];
                    echo '<div class="alert alert-' . $cls . ' alert-dismissible fade show dash-alert mb-4" role="alert">'
                       . '<i class="bi bi-' . ($icons[$cls] ?? 'info-circle') . ' me-2"></i>'
                       . htmlspecialchars($msg)
                       . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>'
                       . '</div>';
                }
            }
            ?>
