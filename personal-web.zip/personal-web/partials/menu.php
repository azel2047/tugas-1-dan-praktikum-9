<?php
// partials/menu.php — Navbar (col-12)
defined('APP_START') or define('APP_START', true);

$currentPage = $_GET['page'] ?? 'home';
$user = $user ?? null;

// Ambil foto profil user yang login
$navFotoUrl = null;
if (isset($user) && $user) {
    $navUserRow = dbFetchOne('SELECT foto_profil FROM users WHERE id = ? LIMIT 1', 'i', [$user['id']]);
    if ($navUserRow && $navUserRow['foto_profil'] && file_exists(UPLOAD_DIR . $navUserRow['foto_profil'])) {
        $navFotoUrl = UPLOAD_URL . $navUserRow['foto_profil'];
    }
}
?>
<!-- ============================================================ -->
<!--  NAVBAR (col-12)                                              -->
<!-- ============================================================ -->
<nav class="navbar navbar-expand-lg sticky-top glass-navbar" id="mainNavbar">
    <div class="container-fluid px-4">

        <!-- Brand -->
        <a class="navbar-brand d-flex align-items-center gap-2" href="<?= BASE_URL ?>/">
            <div class="brand-icon">
                <i class="bi bi-person-badge-fill"></i>
            </div>
            <span class="fw-bold"><?= APP_NAME ?></span>
        </a>

        <!-- Mobile toggle -->
        <button class="navbar-toggler" type="button"
                data-bs-toggle="collapse" data-bs-target="#navbarMain"
                aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 gap-1">

                <!-- Home -->
                <li class="nav-item">
                    <a class="nav-link <?= ($currentPage === 'home' || $currentPage === '') ? 'active' : '' ?>"
                       href="<?= BASE_URL ?>/?page=home">
                        <i class="bi bi-house me-1"></i>Home
                    </a>
                </li>

                <!-- About Me -->
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage === 'about' ? 'active' : '' ?>"
                       href="<?= BASE_URL ?>/?page=about">
                        <i class="bi bi-person me-1"></i>About Me
                    </a>
                </li>

                <!-- Contact Me -->
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage === 'contact' ? 'active' : '' ?>"
                       href="<?= BASE_URL ?>/?page=contact">
                        <i class="bi bi-envelope me-1"></i>Contact Me
                    </a>
                </li>

                <!-- My Studies — Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?= in_array($currentPage, ['my_studies','level','studies']) ? 'active' : '' ?>"
                       href="#" id="studiesDropdown" role="button"
                       data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-mortarboard me-1"></i>My Studies
                    </a>
                    <ul class="dropdown-menu glass-dropdown" aria-labelledby="studiesDropdown">
                        <li>
                            <a class="dropdown-item" href="<?= BASE_URL ?>/?page=my_studies">
                                <i class="bi bi-eye me-2"></i>Lihat Studi
                            </a>
                        </li>
                        <?php if ($user): ?>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item" href="<?= BASE_URL ?>/crud/level/index.php">
                                <i class="bi bi-layers me-2"></i>Kelola Level
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="<?= BASE_URL ?>/crud/studies/index.php">
                                <i class="bi bi-book me-2"></i>Kelola Studies
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
            </ul>

            <!-- Right side: Login or User Info -->
            <ul class="navbar-nav ms-auto align-items-center gap-2">
                <?php if ($user): ?>
                    <!-- Logged in: show user name + role + logout -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center gap-2 user-menu-trigger"
                           href="#" id="userDropdown" role="button"
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="user-avatar <?= $navFotoUrl ? '' : 'no-photo' ?>">
                            <?php if ($navFotoUrl): ?>
                                <img src="<?= htmlspecialchars($navFotoUrl) ?>" alt="Foto Profil">
                            <?php else: ?>
                                <?= strtoupper(substr($user['nama_lengkap'], 0, 1)) ?>
                            <?php endif; ?>
                        </div>
                            <div class="d-none d-sm-block text-start">
                                <div class="fw-semibold lh-1" style="font-size:.85rem;">
                                    <?= htmlspecialchars($user['nama_lengkap']) ?>
                                </div>
                                <div class="text-muted lh-1" style="font-size:.72rem;">
                                    <?= ucfirst(htmlspecialchars($user['role'])) ?>
                                </div>
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end glass-dropdown" aria-labelledby="userDropdown">
                            <li>
                                <div class="dropdown-item-text px-3 py-2">
                                    <div class="fw-bold"><?= htmlspecialchars($user['nama_lengkap']) ?></div>
                                    <small class="text-muted">@<?= htmlspecialchars($user['username']) ?> · <?= ucfirst($user['role']) ?></small>
                                </div>
                            </li>
                            <li><hr class="dropdown-divider my-1"></li>
                            <li>
                                <a class="dropdown-item" href="<?= BASE_URL ?>/dashboard/profile.php">
                                    <i class="bi bi-camera me-2"></i>Foto Profil
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?= BASE_URL ?>/dashboard/">
                                    <i class="bi bi-grid-1x2 me-2"></i>Dashboard Admin
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item text-muted" href="<?= BASE_URL ?>/">
                                    <i class="bi bi-house me-2"></i>Beranda
                                </a>
                            </li>
                            <li><hr class="dropdown-divider my-1"></li>
                            <li>
                                <form method="POST" action="<?= BASE_URL ?>/auth/logout.php">
                                    <?= csrfField() ?>
                                    <button type="submit" class="dropdown-item text-danger">
                                        <i class="bi bi-box-arrow-right me-2"></i>Logout
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </li>
                <?php else: ?>
                    <!-- Not logged in: show Login button -->
                    <li class="nav-item">
                        <a href="<?= BASE_URL ?>/auth/login.php"
                           class="btn btn-primary btn-sm px-3 rounded-pill <?= basename($_SERVER['PHP_SELF']) === 'login.php' ? 'active' : '' ?>">
                            <i class="bi bi-box-arrow-in-right me-1"></i>Login
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<!-- end navbar -->
