<?php
// partials/sidebar.php — col-md-3
defined('APP_START') or define('APP_START', true);

$currentPage = $_GET['page'] ?? 'home';

// Ambil foto profil dari owner/author (user ID 1)
$fotoProfilUrl = null;
$authorId = 1; // Ganti jika user owner punya ID berbeda
$userRow = dbFetchOne('SELECT foto_profil FROM users WHERE id = ? LIMIT 1', 'i', [$authorId]);
if ($userRow && $userRow['foto_profil'] && file_exists(UPLOAD_DIR . $userRow['foto_profil'])) {
    $fotoProfilUrl = UPLOAD_URL . $userRow['foto_profil'];
}
?>
<!-- ============================================================ -->
<!--  SIDEBAR (col-md-3)                                          -->
<!-- ============================================================ -->
<aside class="col-md-3">

    <!-- ---- Profile Mini Card ---- -->
    <div class="glass-card p-3 mb-3 text-center">
        <!-- Foto Profil -->
        <div class="sidebar-avatar mx-auto mb-3">
            <?php if ($fotoProfilUrl): ?>
                <img src="<?= htmlspecialchars($fotoProfilUrl) ?>" alt="Foto Profil">
            <?php else: ?>
                <i class="bi bi-person-circle" style="font-size:2.4rem;"></i>
            <?php endif; ?>
        </div>

        <h6 class="fw-bold mb-0" style="font-size:.92rem;">Ugroseno Dwi Prakastyo</h6>
        <p class="text-muted small mb-1" style="font-size:.78rem;">Full-Stack Web Developer</p>
        <p class="mb-3" style="font-size:.72rem;">
            <span class="badge" style="background:rgba(16,185,129,.1);color:#059669;border:1px solid rgba(16,185,129,.2);border-radius:20px;padding:.25rem .75rem;">
                <i class="bi bi-circle-fill me-1" style="font-size:.45rem;"></i>Available
            </span>
        </p>
        <div class="d-flex justify-content-center gap-2">
            <a href="https://github.com/ugroseno" target="_blank" rel="noopener"
               class="btn btn-outline-dark btn-sm rounded-pill px-3" style="font-size:.75rem;">
                <i class="bi bi-github me-1"></i>GitHub
            </a>
            <a href="https://linkedin.com/in/ugroseno" target="_blank" rel="noopener"
               class="btn btn-sm rounded-pill px-3" style="font-size:.75rem;background:#0077b5;color:white;">
                <i class="bi bi-linkedin me-1"></i>LinkedIn
            </a>
        </div>
    </div>

    <!-- ---- Quick Navigation ---- -->
    <div class="glass-card p-3 mb-3">
        <h6 class="fw-bold text-uppercase mb-3 ps-1"
            style="font-size:.65rem;letter-spacing:.1em;color:var(--c-text-light,#9ca3af);">
            <i class="bi bi-compass me-1"></i> Navigasi
        </h6>
        <div class="list-group list-group-flush sidebar-nav">
            <a href="<?= BASE_URL ?>/?page=home"
               class="list-group-item list-group-item-action <?= ($currentPage==='home'||$currentPage==='') ? 'active':'' ?>">
                <i class="bi bi-house-door"></i><span>Beranda</span>
            </a>
            <a href="<?= BASE_URL ?>/?page=about"
               class="list-group-item list-group-item-action <?= $currentPage==='about' ? 'active':'' ?>">
                <i class="bi bi-person-lines-fill"></i><span>Tentang Saya</span>
            </a>
            <a href="<?= BASE_URL ?>/?page=contact"
               class="list-group-item list-group-item-action <?= $currentPage==='contact' ? 'active':'' ?>">
                <i class="bi bi-envelope-open"></i><span>Hubungi Saya</span>
            </a>
            <a href="<?= BASE_URL ?>/?page=my_studies"
               class="list-group-item list-group-item-action <?= $currentPage==='my_studies' ? 'active':'' ?>">
                <i class="bi bi-mortarboard"></i><span>Riwayat Studi</span>
            </a>
        </div>
    </div>

    <!-- ---- Admin Panel (only when logged in) ---- -->
    <?php if (isset($user) && $user): ?>
    <div class="glass-card p-3 mb-3">
        <h6 class="fw-bold text-uppercase mb-3 ps-1"
            style="font-size:.65rem;letter-spacing:.1em;color:var(--c-text-light,#9ca3af);">
            <i class="bi bi-shield-lock me-1"></i> Admin
        </h6>
        <div class="list-group list-group-flush sidebar-nav">
            <a href="<?= BASE_URL ?>/dashboard/"
               class="list-group-item list-group-item-action">
                <i class="bi bi-grid-1x2"></i><span>Dashboard</span>
            </a>
            <a href="<?= BASE_URL ?>/dashboard/profile.php"
               class="list-group-item list-group-item-action">
                <i class="bi bi-camera"></i><span>Foto Profil</span>
            </a>
            <a href="<?= BASE_URL ?>/crud/level/index.php"
               class="list-group-item list-group-item-action">
                <i class="bi bi-layers"></i><span>Kelola Level</span>
            </a>
            <a href="<?= BASE_URL ?>/crud/studies/index.php"
               class="list-group-item list-group-item-action">
                <i class="bi bi-book-half"></i><span>Kelola Studies</span>
            </a>
        </div>
    </div>
    <?php endif; ?>

    <!-- ---- Stats Widget ---- -->
    <?php
    $totalStudies = dbFetchOne('SELECT COUNT(*) as cnt FROM studies')['cnt'] ?? 0;
    $totalLevel   = dbFetchOne('SELECT COUNT(*) as cnt FROM level')['cnt']   ?? 0;
    ?>
    <div class="glass-card p-3">
        <h6 class="fw-bold text-uppercase mb-3 ps-1"
            style="font-size:.65rem;letter-spacing:.1em;color:var(--c-text-light,#9ca3af);">
            <i class="bi bi-bar-chart me-1"></i> Statistik
        </h6>
        <div class="d-flex justify-content-between align-items-center mb-2 px-1">
            <span style="font-size:.8rem;color:var(--c-text-muted,#6b7280);">
                <i class="bi bi-mortarboard me-1" style="color:#4f46e5;"></i>Total Studi
            </span>
            <span class="badge rounded-pill"
                  style="background:rgba(79,70,229,.1);color:#4f46e5;font-size:.78rem;">
                <?= $totalStudies ?>
            </span>
        </div>
        <div class="d-flex justify-content-between align-items-center px-1">
            <span style="font-size:.8rem;color:var(--c-text-muted,#6b7280);">
                <i class="bi bi-layers me-1" style="color:#6366f1;"></i>Total Level
            </span>
            <span class="badge rounded-pill"
                  style="background:rgba(99,102,241,.1);color:#6366f1;font-size:.78rem;">
                <?= $totalLevel ?>
            </span>
        </div>
    </div>

</aside>
<!-- end sidebar -->
