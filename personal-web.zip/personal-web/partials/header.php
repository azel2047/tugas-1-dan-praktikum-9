<?php
defined('APP_START') or define('APP_START', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../auth/check_auth.php';

startSecureSession();
$user = currentUser();
$currentPage = basename($_SERVER['PHP_SELF']);
$pageTitle = $pageTitle ?? APP_NAME;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Personal Home Page — Portofolio dan profil pribadi <?= APP_AUTHOR ?>">
    <meta name="author" content="<?= APP_AUTHOR ?>">
    <title><?= htmlspecialchars($pageTitle) ?> — <?= APP_NAME ?></title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Bootswatch Lux (Bootstrap 5) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/lux/bootstrap.min.css">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<!-- ============================================================ -->
<!--  HERO CAROUSEL (col-12)                                       -->
<!-- ============================================================ -->
<header class="site-header">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">

        <!-- Indicators -->
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>

        <div class="carousel-inner">
            <!-- Slide 1 -->
            <div class="carousel-item active">
                <div class="carousel-bg slide-1"></div>
                <div class="carousel-caption">
                    <div class="caption-glass">
                        <span class="badge bg-primary-subtle text-primary mb-2 px-3 py-2 rounded-pill">
                            <i class="bi bi-stars me-1"></i> Welcome
                        </span>
                        <h2 class="display-5 fw-bold text-white">Selamat Datang</h2>
                        <p class="lead text-white-75">Personal page saya — tempat berbagi cerita, karya, dan pengalaman.</p>
                        <a href="<?= BASE_URL ?>/?page=home" class="btn btn-light btn-lg rounded-pill px-4">
                            <i class="bi bi-person-circle me-2"></i>Lihat Profil
                        </a>
                    </div>
                </div>
            </div>

            <!-- Slide 2 -->
            <div class="carousel-item">
                <div class="carousel-bg slide-2"></div>
                <div class="carousel-caption">
                    <div class="caption-glass">
                        <span class="badge bg-warning-subtle text-warning mb-2 px-3 py-2 rounded-pill">
                            <i class="bi bi-mortarboard me-1"></i> Education
                        </span>
                        <h2 class="display-5 fw-bold text-white">Riwayat Pendidikan</h2>
                        <p class="lead text-white-75">Perjalanan akademis dari TK hingga perguruan tinggi.</p>
                        <a href="<?= BASE_URL ?>/?page=my_studies" class="btn btn-light btn-lg rounded-pill px-4">
                            <i class="bi bi-book me-2"></i>My Studies
                        </a>
                    </div>
                </div>
            </div>

            <!-- Slide 3 -->
            <div class="carousel-item">
                <div class="carousel-bg slide-3"></div>
                <div class="carousel-caption">
                    <div class="caption-glass">
                        <span class="badge bg-success-subtle text-success mb-2 px-3 py-2 rounded-pill">
                            <i class="bi bi-envelope me-1"></i> Contact
                        </span>
                        <h2 class="display-5 fw-bold text-white">Mari Terhubung</h2>
                        <p class="lead text-white-75">Temukan saya di berbagai platform media sosial.</p>
                        <a href="<?= BASE_URL ?>/?page=contact" class="btn btn-light btn-lg rounded-pill px-4">
                            <i class="bi bi-send me-2"></i>Hubungi Saya
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
</header>
<!-- end header -->
