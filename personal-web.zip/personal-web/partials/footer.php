<?php
?>
<!-- ============================================================ -->
<!--  FOOTER (col-12)                                              -->
<!-- ============================================================ -->
<footer class="site-footer mt-5">
    <!-- Flash Messages as Alerts -->
    <?php $flashHtml = renderFlashMessages(); ?>
    <?php if ($flashHtml): ?>
    <div class="container-fluid px-4 mb-3">
        <?= $flashHtml ?>
    </div>
    <?php endif; ?>

    <div class="footer-inner">
        <div class="container-fluid px-4">

            <!-- Footer Alert Info -->
            <div class="alert alert-info alert-dismissible fade show glass-alert mb-4" role="alert">
                <i class="bi bi-info-circle-fill me-2"></i>
                <strong>Selamat datang!</strong> Ini adalah personal home page milik <strong>Ugroseno Dwi Prakastyo</strong>. Gunakan menu navigasi untuk menjelajahi konten.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

            <div class="row g-4 py-4">
                <!-- About Column -->
                <div class="col-md-4">
                    <h6 class="fw-bold mb-3"><?= APP_NAME ?></h6>
                    <p class="text-muted small">
                        Platform personal milik <strong>Ugroseno Dwi Prakastyo</strong> untuk berbagi
                        profil, pengalaman belajar, dan riwayat pendidikan.
                        Dibangun dengan PHP native, MySQL &amp; Bootstrap 5.
                    </p>
                    <div class="d-flex gap-2">
                        <a href="#" class="social-icon" title="GitHub">
                            <i class="bi bi-github"></i>
                        </a>
                        <a href="#" class="social-icon" title="LinkedIn">
                            <i class="bi bi-linkedin"></i>
                        </a>
                        <a href="#" class="social-icon" title="Instagram">
                            <i class="bi bi-instagram"></i>
                        </a>
                        <a href="#" class="social-icon" title="Twitter/X">
                            <i class="bi bi-twitter-x"></i>
                        </a>
                    </div>
                </div>

                <!-- Quick Links Column -->
                <div class="col-md-4">
                    <h6 class="fw-bold mb-3">Navigasi</h6>
                    <ul class="list-unstyled footer-links small">
                        <li><a href="<?= BASE_URL ?>/?page=home"><i class="bi bi-chevron-right me-1"></i>Beranda</a></li>
                        <li><a href="<?= BASE_URL ?>/?page=about"><i class="bi bi-chevron-right me-1"></i>Tentang Saya</a></li>
                        <li><a href="<?= BASE_URL ?>/?page=contact"><i class="bi bi-chevron-right me-1"></i>Hubungi Saya</a></li>
                        <li><a href="<?= BASE_URL ?>/?page=my_studies"><i class="bi bi-chevron-right me-1"></i>Riwayat Studi</a></li>
                    </ul>
                </div>

                <!-- Contact Info Column -->
                <div class="col-md-4">
                    <h6 class="fw-bold mb-3">Kontak</h6>
                    <ul class="list-unstyled small text-muted">
                        <li class="mb-2">
                            <i class="bi bi-envelope-fill me-2 text-primary"></i>
                            <a href="mailto:azelxiteer@gmail.com" class="text-decoration-none">azelxiteer@gmail.com</a>
                        </li>
                        <li class="mb-2">
                            <i class="bi bi-telephone-fill me-2 text-primary"></i>
                            +62 8xx xxxx xxxx
                        </li>
                        <li>
                            <i class="bi bi-geo-alt-fill me-2 text-primary"></i>
                            Indonesia
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Copyright Bar -->
            <div class="footer-bottom d-flex flex-column flex-sm-row justify-content-between align-items-center pt-3">
                <p class="text-muted small mb-1 mb-sm-0">
                    &copy; <?= date('Y') ?> <?= APP_NAME ?> by <?= APP_AUTHOR ?>. All rights reserved.
                </p>
                <p class="text-muted small mb-0">
                    Built with <i class="bi bi-heart-fill text-danger"></i> using PHP, MySQL & Bootstrap 5
                </p>
            </div>
        </div>
    </div>
</footer>
<!-- end footer -->

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>
</html>
