<?php
define('APP_START', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../auth/check_auth.php';

requireLogin();
startSecureSession();

$user      = currentUser();
$userRow   = dbFetchOne('SELECT * FROM users WHERE id = ? LIMIT 1', 'i', [$user['id']]);
$errors    = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCsrf();

    // ---- Hapus foto ----
    if (isset($_POST['action']) && $_POST['action'] === 'delete_photo') {
        if ($userRow['foto_profil']) {
            $path = UPLOAD_DIR . $userRow['foto_profil'];
            if (file_exists($path)) @unlink($path);
        }
        dbExecute('UPDATE users SET foto_profil = NULL WHERE id = ?', 'i', [$user['id']]);
        // Update session
        setFlash('success', 'Foto profil berhasil dihapus.');
        header('Location: ' . BASE_URL . '/dashboard/profile.php');
        exit;
    }

    // ---- Upload foto baru ----
    if (!empty($_FILES['foto_profil']['name'])) {
        $file    = $_FILES['foto_profil'];
        $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $newName = 'profile_' . $user['id'] . '_' . time() . '.' . $ext;

        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errors['foto'] = 'Terjadi kesalahan saat upload.';
        } elseif (!in_array($ext, ALLOWED_EXTENSIONS)) {
            $errors['foto'] = 'Format tidak didukung. Gunakan JPG, PNG, GIF, atau WEBP.';
        } elseif ($file['size'] > MAX_FILE_SIZE) {
            $errors['foto'] = 'Ukuran file terlalu besar. Maksimal 2 MB.';
        } else {
            if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);

            if (move_uploaded_file($file['tmp_name'], UPLOAD_DIR . $newName)) {
                // Hapus foto lama
                if ($userRow['foto_profil']) {
                    $oldPath = UPLOAD_DIR . $userRow['foto_profil'];
                    if (file_exists($oldPath)) @unlink($oldPath);
                }
                dbExecute('UPDATE users SET foto_profil = ? WHERE id = ?', 'si', [$newName, $user['id']]);
                setFlash('success', 'Foto profil berhasil diperbarui!');
                header('Location: ' . BASE_URL . '/dashboard/profile.php');
                exit;
            } else {
                $errors['foto'] = 'Gagal menyimpan file. Periksa permission folder uploads.';
            }
        }
    } else {
        $errors['foto'] = 'Pilih file foto terlebih dahulu.';
    }
}

// Reload user data
$userRow   = dbFetchOne('SELECT * FROM users WHERE id = ? LIMIT 1', 'i', [$user['id']]);
$fotoUrl   = ($userRow['foto_profil'] && file_exists(UPLOAD_DIR . $userRow['foto_profil']))
             ? UPLOAD_URL . $userRow['foto_profil']
             : null;

$pageTitle  = 'Foto Profil';
$breadcrumb = [['label' => 'Foto Profil', 'url' => '']];
require_once __DIR__ . '/../partials/dashboard_layout.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-7">

        <!-- Preview Card -->
        <div class="dash-card mb-3">
            <div class="dash-card-header">
                <h6 class="dash-card-title">
                    <i class="bi bi-person-circle me-2 text-primary"></i>Foto Profil Saat Ini
                </h6>
            </div>
            <div class="dash-card-body text-center py-4">
                <?php if ($fotoUrl): ?>
                    <img src="<?= htmlspecialchars($fotoUrl) ?>"
                         alt="Foto Profil"
                         id="currentPhoto"
                         style="width:140px;height:140px;object-fit:cover;border-radius:50%;
                                border:4px solid #e2e8f0;box-shadow:0 8px 30px rgba(0,0,0,.12);
                                display:block;margin:0 auto;">
                    <p class="text-muted small mt-3 mb-3">Foto profil Anda saat ini</p>

                    <!-- Hapus Foto -->
                    <form method="POST" action=""
                          onsubmit="return confirm('Yakin ingin menghapus foto profil?')">
                        <?= csrfField() ?>
                        <input type="hidden" name="action" value="delete_photo">
                        <button type="submit" class="dash-btn dash-btn-danger">
                            <i class="bi bi-trash me-1"></i> Hapus Foto
                        </button>
                    </form>
                <?php else: ?>
                    <div style="width:140px;height:140px;border-radius:50%;margin:0 auto;
                                background:linear-gradient(135deg,#4f46e5,#8b5cf6);
                                display:flex;align-items:center;justify-content:center;
                                font-size:4rem;color:white;border:4px solid #e2e8f0;
                                box-shadow:0 8px 30px rgba(79,70,229,.2);">
                        <i class="bi bi-person-fill"></i>
                    </div>
                    <p class="text-muted small mt-3">Belum ada foto profil. Upload di bawah ini.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Upload Form Card -->
        <div class="dash-card">
            <div class="dash-card-header">
                <h6 class="dash-card-title">
                    <i class="bi bi-cloud-arrow-up me-2 text-primary"></i>Upload Foto Baru
                </h6>
            </div>
            <div class="dash-card-body">
                <?php if (!empty($errors['foto'])): ?>
                    <div class="alert alert-danger dash-alert mb-3">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <?= htmlspecialchars($errors['foto']) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" enctype="multipart/form-data" novalidate>
                    <?= csrfField() ?>

                    <!-- Drag & Drop Upload Area -->
                    <div class="upload-area mb-4" id="uploadArea"
                         onclick="document.getElementById('foto_profil').click()"
                         style="border:2px dashed #c7d2fe;border-radius:14px;padding:2.5rem;
                                text-align:center;cursor:pointer;background:#fafafe;
                                transition:all .2s ease;">
                        <div id="uploadPreview" style="display:none;margin-bottom:12px;">
                            <img id="previewImg" src="#" alt="Preview"
                                 style="width:110px;height:110px;object-fit:cover;border-radius:50%;
                                        border:3px solid #c7d2fe;box-shadow:0 4px 16px rgba(0,0,0,.1);">
                        </div>
                        <div id="uploadPlaceholder">
                            <i class="bi bi-cloud-arrow-up" style="font-size:2.5rem;color:#a5b4fc;display:block;margin-bottom:8px;"></i>
                            <p class="mb-1 fw-semibold" style="color:#4f46e5;">Klik untuk pilih foto</p>
                            <p class="text-muted small mb-0">atau drag &amp; drop di sini</p>
                        </div>
                        <p class="text-muted mt-3 mb-0" style="font-size:.75rem;">
                            Format: JPG, PNG, GIF, WEBP &bull; Maks. 2 MB
                        </p>
                    </div>

                    <!-- Hidden file input -->
                    <input type="file" id="foto_profil" name="foto_profil"
                           accept="image/*" style="display:none;" required>

                    <!-- Selected filename display -->
                    <div id="fileNameDisplay" class="text-muted small text-center mb-3" style="display:none;">
                        <i class="bi bi-file-earmark-image me-1"></i>
                        <span id="fileNameText"></span>
                    </div>

                    <div class="d-flex gap-2 justify-content-center">
                        <button type="submit" class="dash-btn dash-btn-primary px-4" id="uploadBtn" disabled>
                            <i class="bi bi-cloud-upload me-1"></i> Simpan Foto Profil
                        </button>
                        <a href="<?= BASE_URL ?>/dashboard/" class="dash-btn dash-btn-outline">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    const input      = document.getElementById('foto_profil');
    const area       = document.getElementById('uploadArea');
    const preview    = document.getElementById('uploadPreview');
    const placeholder = document.getElementById('uploadPlaceholder');
    const previewImg = document.getElementById('previewImg');
    const fileNameDisplay = document.getElementById('fileNameDisplay');
    const fileNameText    = document.getElementById('fileNameText');
    const uploadBtn  = document.getElementById('uploadBtn');

    // Hover effect
    area.addEventListener('mouseenter', () => area.style.borderColor = '#6366f1');
    area.addEventListener('mouseleave', () => {
        if (!input.files.length) area.style.borderColor = '#c7d2fe';
    });

    // Drag over
    area.addEventListener('dragover', (e) => {
        e.preventDefault();
        area.style.background = '#eef2ff';
        area.style.borderColor = '#6366f1';
    });
    area.addEventListener('dragleave', () => {
        area.style.background = '#fafafe';
        area.style.borderColor = '#c7d2fe';
    });
    area.addEventListener('drop', (e) => {
        e.preventDefault();
        area.style.background = '#fafafe';
        const dt = e.dataTransfer;
        if (dt.files.length) {
            // Assign dropped file
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(dt.files[0]);
            input.files = dataTransfer.files;
            handleFile(dt.files[0]);
        }
    });

    input.addEventListener('change', function () {
        if (this.files.length) handleFile(this.files[0]);
    });

    function handleFile(file) {
        if (!file.type.startsWith('image/')) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            previewImg.src = e.target.result;
            preview.style.display    = 'block';
            placeholder.style.display = 'none';
            fileNameDisplay.style.display = 'block';
            fileNameText.textContent = file.name + ' (' + (file.size / 1024).toFixed(0) + ' KB)';
            uploadBtn.disabled = false;
            area.style.borderColor = '#6366f1';
            area.style.background  = '#eef2ff';
        };
        reader.readAsDataURL(file);
    }
})();
</script>

<?php require_once __DIR__ . '/../partials/dashboard_layout_close.php'; ?>
