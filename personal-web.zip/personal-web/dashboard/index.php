<?php
define('APP_START', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../auth/check_auth.php';

requireLogin();

$pageTitle  = 'Dashboard';
$breadcrumb = [];

require_once __DIR__ . '/../partials/dashboard_layout.php';

// Fetch stats
$totalStudies  = (int)(dbFetchOne('SELECT COUNT(*) AS c FROM studies')['c']  ?? 0);
$totalLevels   = (int)(dbFetchOne('SELECT COUNT(*) AS c FROM level')['c']    ?? 0);
$latestStudy   = dbFetchOne('SELECT s.nama, s.tahun_lulus, l.nama AS level FROM studies s JOIN level l ON s.idlevel=l.id ORDER BY s.tahun_lulus DESC LIMIT 1');
$recentStudies = dbFetchAll('SELECT s.id, s.nama, s.tahun_lulus, l.nama AS level FROM studies s JOIN level l ON s.idlevel=l.id ORDER BY s.id DESC LIMIT 5');
$allLevels     = dbFetchAll('SELECT l.nama, COUNT(s.id) AS jml FROM level l LEFT JOIN studies s ON l.id=s.idlevel GROUP BY l.id ORDER BY jml DESC LIMIT 5');
?>

<!-- ---- Stat Cards ---------------------------------------- -->
<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3">
        <div class="dash-stat">
            <div class="dash-stat-icon" style="background:rgba(59,130,246,.12);color:#3b82f6;">
                <i class="bi bi-mortarboard-fill"></i>
            </div>
            <div>
                <div class="dash-stat-num"><?= $totalStudies ?></div>
                <div class="dash-stat-label">Total Studi</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="dash-stat">
            <div class="dash-stat-icon" style="background:rgba(16,185,129,.12);color:#10b981;">
                <i class="bi bi-layers-fill"></i>
            </div>
            <div>
                <div class="dash-stat-num"><?= $totalLevels ?></div>
                <div class="dash-stat-label">Total Level</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="dash-stat">
            <div class="dash-stat-icon" style="background:rgba(139,92,246,.12);color:#8b5cf6;">
                <i class="bi bi-calendar-check-fill"></i>
            </div>
            <div>
                <div class="dash-stat-num"><?= $latestStudy['tahun_lulus'] ?? '—' ?></div>
                <div class="dash-stat-label">Tahun Lulus Terakhir</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="dash-stat">
            <div class="dash-stat-icon" style="background:rgba(245,158,11,.12);color:#f59e0b;">
                <i class="bi bi-person-fill-check"></i>
            </div>
            <div>
                <div class="dash-stat-num" style="font-size:1.1rem;">
                    <?= htmlspecialchars($user['role'] ?? '—') ?>
                </div>
                <div class="dash-stat-label">Role Akun</div>
            </div>
        </div>
    </div>
</div>

<!-- ---- Welcome Banner ------------------------------------- -->
<div class="dash-card mb-4" style="background:linear-gradient(135deg,#1e3a5f,#2563eb);color:white;">
    <div class="dash-card-body d-flex align-items-center justify-content-between flex-wrap gap-3">
        <div>
            <h4 class="fw-bold mb-1" style="color:white;">
                Selamat datang, <?= htmlspecialchars($user['nama_lengkap'] ?? 'Admin') ?>! 👋
            </h4>
            <p style="color:rgba(255,255,255,.75);margin:0;font-size:.88rem;">
                Anda login sebagai <strong><?= htmlspecialchars($user['username'] ?? '') ?></strong> &mdash;
                <?= ucfirst($user['role'] ?? '') ?>.
                Kelola konten personal page Anda dari sini.
            </p>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <a href="<?= BASE_URL ?>/crud/studies/create.php" class="btn btn-light btn-sm rounded-pill px-3">
                <i class="bi bi-plus-lg me-1"></i>Tambah Studi
            </a>
            <a href="<?= BASE_URL ?>/crud/level/create.php" class="btn btn-outline-light btn-sm rounded-pill px-3">
                <i class="bi bi-plus me-1"></i>Tambah Level
            </a>
        </div>
    </div>
</div>

<!-- ---- Two Columns: Recent Studies + Level Summary -------- -->
<div class="row g-3">

    <!-- Recent Studies -->
    <div class="col-lg-7">
        <div class="dash-card">
            <div class="dash-card-header">
                <h6 class="dash-card-title">
                    <i class="bi bi-mortarboard me-2 text-primary"></i>Studi Terbaru
                </h6>
                <a href="<?= BASE_URL ?>/crud/studies/index.php" class="dash-btn dash-btn-outline" style="font-size:.75rem;">
                    Lihat Semua <i class="bi bi-arrow-right ms-1"></i>
                </a>
            </div>
            <div class="dash-card-body" style="padding:0;">
                <?php if (empty($recentStudies)): ?>
                    <div class="text-center py-5 text-muted">
                        <i class="bi bi-inbox" style="font-size:2rem;"></i>
                        <p class="mt-2 small">Belum ada data studi.</p>
                        <a href="<?= BASE_URL ?>/crud/studies/create.php" class="dash-btn dash-btn-primary">
                            <i class="bi bi-plus"></i> Tambah Sekarang
                        </a>
                    </div>
                <?php else: ?>
                    <table class="table dash-table mb-0">
                        <thead>
                            <tr>
                                <th>Institusi</th>
                                <th>Level</th>
                                <th>Tahun</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentStudies as $s): ?>
                            <tr>
                                <td class="fw-semibold"><?= htmlspecialchars($s['nama']) ?></td>
                                <td>
                                    <span class="dash-badge" style="background:rgba(59,130,246,.1);color:#3b82f6;">
                                        <?= htmlspecialchars($s['level']) ?>
                                    </span>
                                </td>
                                <td style="color:#64748b;"><?= $s['tahun_lulus'] ?></td>
                                <td class="text-center">
                                    <a href="<?= BASE_URL ?>/crud/studies/edit.php?id=<?= $s['id'] ?>"
                                       class="dash-btn dash-btn-outline" style="font-size:.72rem;padding:.2rem .55rem;">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Level Summary + Quick Actions -->
    <div class="col-lg-5 d-flex flex-column gap-3">

        <!-- Level Summary -->
        <div class="dash-card">
            <div class="dash-card-header">
                <h6 class="dash-card-title">
                    <i class="bi bi-layers me-2 text-success"></i>Ringkasan Level
                </h6>
                <a href="<?= BASE_URL ?>/crud/level/index.php" class="dash-btn dash-btn-outline" style="font-size:.75rem;">
                    Kelola <i class="bi bi-arrow-right ms-1"></i>
                </a>
            </div>
            <div class="dash-card-body">
                <?php if (empty($allLevels)): ?>
                    <p class="text-muted small text-center mb-0">Belum ada level.</p>
                <?php else: ?>
                    <?php foreach ($allLevels as $lv): ?>
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <div class="d-flex align-items-center gap-2">
                            <div style="width:8px;height:8px;background:#3b82f6;border-radius:50%;"></div>
                            <span style="font-size:.84rem;font-weight:500;"><?= htmlspecialchars($lv['nama']) ?></span>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <div style="flex:1;height:6px;background:#f1f5f9;border-radius:3px;width:80px;">
                                <?php $pct = $totalStudies > 0 ? ($lv['jml'] / $totalStudies * 100) : 0; ?>
                                <div style="width:<?= round($pct) ?>%;height:100%;background:#3b82f6;border-radius:3px;"></div>
                            </div>
                            <span class="dash-badge" style="background:#f1f5f9;color:#475569;"><?= $lv['jml'] ?></span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="dash-card">
            <div class="dash-card-header">
                <h6 class="dash-card-title"><i class="bi bi-lightning-fill me-2 text-warning"></i>Aksi Cepat</h6>
            </div>
            <div class="dash-card-body d-flex flex-column gap-2">
                <a href="<?= BASE_URL ?>/crud/studies/create.php" class="dash-btn dash-btn-primary w-100 justify-content-center">
                    <i class="bi bi-plus-lg"></i> Tambah Studi Baru
                </a>
                <a href="<?= BASE_URL ?>/crud/level/create.php" class="dash-btn dash-btn-outline w-100 justify-content-center">
                    <i class="bi bi-plus"></i> Tambah Level Baru
                </a>
                <a href="<?= BASE_URL ?>/" class="dash-btn dash-btn-outline w-100 justify-content-center" target="_blank">
                    <i class="bi bi-eye"></i> Lihat Situs Publik
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../partials/dashboard_layout_close.php'; ?>
