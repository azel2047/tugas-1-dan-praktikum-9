<?php
// ============================================================
// Global Application Configuration
// ============================================================

// Prevent direct access
if (!defined('APP_START')) {
    define('APP_START', true);
}

// Application Info
define('APP_NAME',    'Ugroseno D.P.');
define('APP_VERSION', '1.0.0');
define('APP_AUTHOR',  'Ugroseno Dwi Prakastyo');

// Base URL — adjust if needed (no trailing slash)
define('BASE_URL', 'http://personal-web.test');

// Upload directory (absolute path)
define('UPLOAD_DIR',  __DIR__ . '/../assets/uploads/');
define('UPLOAD_URL',  BASE_URL . '/assets/uploads/');

// Allowed image extensions for upload
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('MAX_FILE_SIZE', 2 * 1024 * 1024); // 2 MB

// Session configuration
define('SESSION_NAME',    'personal_web_sess');
define('SESSION_TIMEOUT', 3600); // 1 hour in seconds

// CSRF token session key
define('CSRF_TOKEN_KEY', '_csrf_token');

// Error display (set false in production)
define('DEBUG_MODE', true);
