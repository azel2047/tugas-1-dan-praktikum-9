<?php
defined('APP_START') or define('APP_START', true);

require_once __DIR__ . '/config.php';

define('DB_HOST',    'localhost');
define('DB_USER',    'root');
define('DB_PASS',    'root');          
define('DB_NAME',    'personal_web');
define('DB_PORT',    3306);
define('DB_CHARSET', 'utf8mb4');


function getDB(): mysqli
{
    static $conn = null;

    if ($conn === null) {
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

        try {
            $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
            $conn->set_charset(DB_CHARSET);
        } catch (mysqli_sql_exception $e) {
            if (defined('DEBUG_MODE') && DEBUG_MODE) {
                die('<div style="padding:20px;font-family:monospace;background:#fee;border:1px solid red;">'
                    . '<strong>Database Connection Error:</strong><br>'
                    . htmlspecialchars($e->getMessage())
                    . '</div>');
            }
            die('A database error occurred. Please try again later.');
        }
    }

    return $conn;
}

/**
 * Execute a prepared statement with bindings.
 *
 * @param string $sql    SQL query with ? placeholders
 * @param string $types  Binding types string (e.g. "ssi")
 * @param array  $params Values to bind
 * @return mysqli_stmt
 */
function dbQuery(string $sql, string $types = '', array $params = []): mysqli_stmt
{
    $conn = getDB();
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        throw new RuntimeException('Prepare failed: ' . $conn->error);
    }

    if ($types && $params) {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    return $stmt;
}

/**
 * Fetch all rows as associative array.
 */
function dbFetchAll(string $sql, string $types = '', array $params = []): array
{
    $stmt   = dbQuery($sql, $types, $params);
    $result = $stmt->get_result();
    $rows   = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

/**
 * Fetch single row as associative array.
 */
function dbFetchOne(string $sql, string $types = '', array $params = []): ?array
{
    $stmt   = dbQuery($sql, $types, $params);
    $result = $stmt->get_result();
    $row    = $result->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

/**
 * Execute INSERT/UPDATE/DELETE; return affected rows.
 */
function dbExecute(string $sql, string $types = '', array $params = []): int
{
    $stmt          = dbQuery($sql, $types, $params);
    $affectedRows  = $stmt->affected_rows;
    $stmt->close();
    return $affectedRows;
}

/**
 * Return last inserted ID.
 */
function dbLastInsertId(): int
{
    return (int) getDB()->insert_id;
}
