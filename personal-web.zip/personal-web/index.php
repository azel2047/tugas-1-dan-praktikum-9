<?php
// ============================================================
// index.php — Front Controller
// Route: /?page=home|about|contact|my_studies
// ============================================================
define('APP_START', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/auth/check_auth.php';

startSecureSession();
$user = currentUser();

// Allowed pages whitelist
$allowedPages = ['home', 'about', 'contact', 'my_studies'];
$page = $_GET['page'] ?? 'home';
if (!in_array($page, $allowedPages)) {
    $page = 'home';
}

$pageFile  = __DIR__ . '/pages/' . $page . '.php';
$pageTitles = [
    'home'       => 'Beranda',
    'about'      => 'Tentang Saya',
    'contact'    => 'Hubungi Saya',
    'my_studies' => 'Riwayat Studi',
];
$pageTitle = $pageTitles[$page] ?? APP_NAME;

// Load header (outputs HTML <head> + carousel)
require_once __DIR__ . '/partials/header.php';
// Load navbar
require_once __DIR__ . '/partials/menu.php';
?>

<!-- ============================================================ -->
<!--  MAIN WRAPPER — Sidebar (3) + Main Content (9)               -->
<!-- ============================================================ -->
<div class="container-fluid main-wrapper py-4">
    <div class="row g-4">

        <!-- SIDEBAR: col-md-3 -->
        <?php require_once __DIR__ . '/partials/sidebar.php'; ?>

        <!-- MAIN CONTENT: col-md-9 -->
        <main class="col-md-9">
            <?= renderFlashMessages() ?>
            <?php
            if (file_exists($pageFile)) {
                include $pageFile;
            } else {
                echo '<div class="glass-card p-5 text-center text-muted">
                        <i class="bi bi-exclamation-triangle" style="font-size:3rem;"></i>
                        <p class="mt-3">Halaman tidak ditemukan.</p>
                      </div>';
            }
            ?>
        </main>

    </div>
</div>

<?php require_once __DIR__ . '/partials/footer.php'; ?>
