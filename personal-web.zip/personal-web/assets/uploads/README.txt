This directory is used for uploaded school photos.

Files uploaded here will be served publicly.
Do NOT upload PHP files or other scripts to this directory.
