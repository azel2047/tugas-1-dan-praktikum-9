/**
 * Personal Home Page — main.js
 * Client-side interactions, form validation, DOM manipulation
 */

'use strict';

// ============================================================
// Toast Notification System
// ============================================================
function showToast(message, type = 'info') {
    const types = {
        success : { bg: 'bg-success', icon: 'bi-check-circle-fill' },
        error   : { bg: 'bg-danger',  icon: 'bi-exclamation-triangle-fill' },
        warning : { bg: 'bg-warning text-dark', icon: 'bi-exclamation-circle-fill' },
        info    : { bg: 'bg-primary', icon: 'bi-info-circle-fill' },
    };

    const t = types[type] || types.info;

    // Create or get container
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(container);
    }

    const id      = 'toast-' + Date.now();
    const toastEl = document.createElement('div');
    toastEl.id        = id;
    toastEl.className = `toast align-items-center text-white ${t.bg} border-0 rounded-3`;
    toastEl.setAttribute('role', 'alert');
    toastEl.setAttribute('aria-live', 'assertive');
    toastEl.innerHTML = `
        <div class="d-flex">
            <div class="toast-body d-flex align-items-center gap-2">
                <i class="bi ${t.icon}"></i>
                <span>${message}</span>
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;

    container.appendChild(toastEl);
    const bsToast = new bootstrap.Toast(toastEl, { delay: 4000 });
    bsToast.show();
    toastEl.addEventListener('hidden.bs.toast', () => toastEl.remove());
}

// ============================================================
// Auto-dismiss Alerts after 6 seconds
// ============================================================
document.addEventListener('DOMContentLoaded', function () {
    const alerts = document.querySelectorAll('.alert.alert-success, .alert.alert-info');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) bsAlert.close();
        }, 6000);
    });
});

// ============================================================
// Active Nav Link highlight (based on query param)
// ============================================================
document.addEventListener('DOMContentLoaded', function () {
    const params = new URLSearchParams(window.location.search);
    const page   = params.get('page') || 'home';
    document.querySelectorAll('.nav-link[href*="page=' + page + '"]').forEach(function (link) {
        link.classList.add('active');
    });
});

// ============================================================
// Smooth scroll for anchor links
// ============================================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});

// ============================================================
// Navbar scroll shadow
// ============================================================
const navbar = document.getElementById('mainNavbar');
if (navbar) {
    window.addEventListener('scroll', function () {
        if (window.scrollY > 10) {
            navbar.style.boxShadow = '0 4px 30px rgba(44,123,229,0.14)';
        } else {
            navbar.style.boxShadow = '0 2px 20px rgba(44,123,229,0.08)';
        }
    });
}

// ============================================================
// Animate elements on scroll (Intersection Observer)
// ============================================================
document.addEventListener('DOMContentLoaded', function () {
    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.style.opacity    = '1';
                entry.target.style.transform  = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

    document.querySelectorAll('.glass-card, .study-item, .social-card, .hobby-card').forEach(function (el) {
        el.style.opacity    = '0';
        el.style.transform  = 'translateY(20px)';
        el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        observer.observe(el);
    });
});

// ============================================================
// Bootstrap form validation (HTML5 native + Bootstrap classes)
// ============================================================
document.addEventListener('DOMContentLoaded', function () {
    const forms = document.querySelectorAll('form[novalidate]');
    forms.forEach(function (form) {
        if (form.id === 'contactForm') return; // Handled separately
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
});

// ============================================================
// Character counter for textareas
// ============================================================
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('textarea[maxlength]').forEach(function (ta) {
        const max     = ta.getAttribute('maxlength');
        const counter = document.createElement('div');
        counter.className = 'form-text text-end char-counter';
        counter.textContent = '0 / ' + max;
        ta.parentNode.insertBefore(counter, ta.nextSibling);

        ta.addEventListener('input', function () {
            const len = ta.value.length;
            counter.textContent = len + ' / ' + max;
            counter.style.color = len > max * 0.9 ? '#dc3545' : '';
        });
    });
});

// ============================================================
// Confirm delete buttons (data-confirm attribute)
// ============================================================
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-confirm]').forEach(function (el) {
        el.addEventListener('click', function (e) {
            if (!confirm(el.dataset.confirm)) {
                e.preventDefault();
            }
        });
    });
});

// ============================================================
// Image preview helper for file inputs (generic)
// ============================================================
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('input[type="file"][data-preview]').forEach(function (input) {
        const previewId = input.dataset.preview;
        const preview   = document.getElementById(previewId);
        if (!preview) return;

        input.addEventListener('change', function () {
            const file = this.files[0];
            if (file && file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    preview.src             = e.target.result;
                    preview.style.display   = 'block';
                };
                reader.readAsDataURL(file);
            }
        });
    });
});
