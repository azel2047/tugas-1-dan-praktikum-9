<?php
// ============================================================
// Logout Handler
// ============================================================
define('APP_START', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/check_auth.php';

startSecureSession();
validateCsrf();

// Destroy session
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}
session_destroy();

// Restart fresh session for flash message
session_name(SESSION_NAME);
session_start();
setFlash('info', 'Anda telah berhasil logout. Sampai jumpa!');

header('Location: ' . BASE_URL . '/');
exit;
