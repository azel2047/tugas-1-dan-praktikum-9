<?php
// ============================================================
// Auth Middleware — Session & CSRF helpers
// ============================================================

defined('APP_START') or define('APP_START', true);
require_once __DIR__ . '/../config/config.php';

// Start secure session if not already started
function startSecureSession(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_name(SESSION_NAME);
        session_set_cookie_params([
            'lifetime' => SESSION_TIMEOUT,
            'path'     => '/',
            'secure'   => false, // set true on HTTPS
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();

        // Regenerate session ID periodically
        if (!isset($_SESSION['_initiated'])) {
            session_regenerate_id(true);
            $_SESSION['_initiated'] = true;
        }
    }
}

// Check session timeout
function checkSessionTimeout(): void
{
    if (isset($_SESSION['last_activity'])) {
        if (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT) {
            session_unset();
            session_destroy();
            startSecureSession();
        }
    }
    $_SESSION['last_activity'] = time();
}

// Redirect if not logged in
function requireLogin(string $redirectTo = ''): void
{
    startSecureSession();
    checkSessionTimeout();

    if (!isset($_SESSION['user_id'])) {
        $redirect = $redirectTo ?: BASE_URL . '/auth/login.php';
        $_SESSION['flash_error'] = 'Anda harus login terlebih dahulu untuk mengakses halaman ini.';
        header('Location: ' . $redirect);
        exit;
    }
}

// Check if user is logged in (returns bool)
function isLoggedIn(): bool
{
    startSecureSession();
    checkSessionTimeout();
    return isset($_SESSION['user_id']);
}

// Get currently logged-in user info from session
function currentUser(): ?array
{
    if (!isLoggedIn()) return null;
    return [
        'id'           => $_SESSION['user_id']   ?? null,
        'username'     => $_SESSION['username']  ?? null,
        'nama_lengkap' => $_SESSION['nama_lengkap'] ?? null,
        'role'         => $_SESSION['role']      ?? null,
    ];
}

// ---- CSRF Protection ----

function generateCsrfToken(): string
{
    startSecureSession();
    if (empty($_SESSION[CSRF_TOKEN_KEY])) {
        $_SESSION[CSRF_TOKEN_KEY] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_KEY];
}

function verifyCsrfToken(string $token): bool
{
    startSecureSession();
    $stored = $_SESSION[CSRF_TOKEN_KEY] ?? '';
    return hash_equals($stored, $token);
}

function csrfField(): string
{
    $token = generateCsrfToken();
    return '<input type="hidden" name="_csrf_token" value="' . htmlspecialchars($token) . '">';
}

function validateCsrf(): void
{
    $token = $_POST['_csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        http_response_code(403);
        die('CSRF token mismatch. Please go back and try again.');
    }
}

// ---- Flash Messages ----

function setFlash(string $type, string $message): void
{
    startSecureSession();
    $_SESSION['flash'][$type] = $message;
}

function getFlash(string $type): ?string
{
    startSecureSession();
    $msg = $_SESSION['flash'][$type] ?? null;
    unset($_SESSION['flash'][$type]);
    return $msg;
}

function renderFlashMessages(): string
{
    $types = [
        'success' => 'success',
        'error'   => 'danger',
        'warning' => 'warning',
        'info'    => 'info',
    ];

    $html = '';
    foreach ($types as $key => $bsClass) {
        $msg = getFlash($key);
        if ($msg) {
            $html .= '<div class="alert alert-' . $bsClass . ' alert-dismissible fade show" role="alert">'
                   . htmlspecialchars($msg)
                   . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>'
                   . '</div>';
        }
    }
    return $html;
}
