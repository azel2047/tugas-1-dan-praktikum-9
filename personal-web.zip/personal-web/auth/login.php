<?php
// ============================================================
// Login Page
// ============================================================
define('APP_START', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/check_auth.php';

startSecureSession();

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/');
    exit;
}

$errors = [];
$old    = [];

// Process login form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCsrf();

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // Validate
    if (empty($username)) $errors['username'] = 'Username wajib diisi.';
    if (empty($password)) $errors['password'] = 'Password wajib diisi.';

    $old['username'] = htmlspecialchars($username);

    if (empty($errors)) {
        $user = dbFetchOne(
            'SELECT id, username, password, nama_lengkap, role FROM users WHERE username = ? LIMIT 1',
            's',
            [$username]
        );

        if ($user && password_verify($password, $user['password'])) {
            // Regenerate session ID on login
            session_regenerate_id(true);

            $_SESSION['user_id']      = $user['id'];
            $_SESSION['username']     = $user['username'];
            $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
            $_SESSION['role']         = $user['role'];
            $_SESSION['last_activity'] = time();

            setFlash('success', 'Selamat datang, ' . $user['nama_lengkap'] . '!');
            header('Location: ' . BASE_URL . '/');
            exit;
        } else {
            $errors['general'] = 'Username atau password salah.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — <?= APP_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/lux/bootstrap.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body class="login-page d-flex align-items-center justify-content-center min-vh-100">

<div class="container">
    <div class="row justify-content-center">
        <div class="col-12 col-sm-10 col-md-7 col-lg-5">

            <!-- Logo / Title -->
            <div class="text-center mb-4">
                <div class="login-logo mb-3">
                    <i class="bi bi-person-circle" style="font-size:3.5rem; color: var(--color-primary);"></i>
                </div>
                <h1 class="h3 fw-bold" style="color: var(--color-primary);"><?= APP_NAME ?></h1>
                <p class="text-muted small">Masuk ke akun Anda untuk mengelola konten</p>
            </div>

            <!-- Login Card -->
            <div class="glass-card p-4 p-md-5">

                <?php if (!empty($errors['general'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        <?= htmlspecialchars($errors['general']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?= renderFlashMessages() ?>

                <form method="POST" action="" novalidate id="loginForm">
                    <?= csrfField() ?>

                    <!-- Username -->
                    <div class="mb-3">
                        <label for="username" class="form-label fw-semibold">
                            <i class="bi bi-person me-1"></i> Username
                        </label>
                        <input
                            type="text"
                            id="username"
                            name="username"
                            class="form-control glass-input <?= !empty($errors['username']) ? 'is-invalid' : '' ?>"
                            value="<?= $old['username'] ?? '' ?>"
                            placeholder="Masukkan username"
                            autocomplete="username"
                            required
                        >
                        <?php if (!empty($errors['username'])): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($errors['username']) ?></div>
                        <?php endif; ?>
                    </div>

                    <!-- Password -->
                    <div class="mb-4">
                        <label for="password" class="form-label fw-semibold">
                            <i class="bi bi-lock me-1"></i> Password
                        </label>
                        <div class="input-group">
                            <input
                                type="password"
                                id="password"
                                name="password"
                                class="form-control glass-input <?= !empty($errors['password']) ? 'is-invalid' : '' ?>"
                                placeholder="Masukkan password"
                                autocomplete="current-password"
                                required
                            >
                            <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                <i class="bi bi-eye" id="toggleIcon"></i>
                            </button>
                            <?php if (!empty($errors['password'])): ?>
                                <div class="invalid-feedback"><?= htmlspecialchars($errors['password']) ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Submit -->
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg fw-semibold" id="loginBtn">
                            <i class="bi bi-box-arrow-in-right me-2"></i> Masuk
                        </button>
                    </div>
                </form>

                <div class="text-center mt-4">
                    <a href="<?= BASE_URL ?>/" class="text-decoration-none text-muted small">
                        <i class="bi bi-arrow-left me-1"></i> Kembali ke Beranda
                    </a>
                </div>
            </div>

            <p class="text-center text-muted small mt-3">
                &copy; <?= date('Y') ?> <?= APP_NAME ?>. All rights reserved.
            </p>
        </div>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Toggle password visibility
    document.getElementById('togglePassword').addEventListener('click', function () {
        const pwInput  = document.getElementById('password');
        const icon     = document.getElementById('toggleIcon');
        const isHidden = pwInput.type === 'password';
        pwInput.type   = isHidden ? 'text' : 'password';
        icon.className = isHidden ? 'bi bi-eye-slash' : 'bi bi-eye';
    });

    // Disable button on submit to prevent double submit
    document.getElementById('loginForm').addEventListener('submit', function () {
        const btn = document.getElementById('loginBtn');
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Memproses...';
    });
</script>
</body>
</html>
